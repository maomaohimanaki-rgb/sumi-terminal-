package dev.sumi.terminal.nativebridge

/** Callbacks invocados da thread nativa "pty-reader" (nunca da main thread). */
interface PtyListener {
    fun onOutput(data: ByteArray)
    fun onExit(code: Int)
    fun onReaderStarted(tid: Int)
}

object PtyNative {
    init { System.loadLibrary("pty_core") }

    external fun nativeStart(
        cmd: String, args: Array<String>, env: Array<String>, cwd: String,
        rows: Int, cols: Int, listener: PtyListener,
    ): Long

    external fun nativeWrite(handle: Long, data: ByteArray): Int
    external fun nativeResize(handle: Long, rows: Int, cols: Int)
    external fun nativeKill(handle: Long, sig: Int)
    external fun nativeReaderTid(handle: Long): Int
}
