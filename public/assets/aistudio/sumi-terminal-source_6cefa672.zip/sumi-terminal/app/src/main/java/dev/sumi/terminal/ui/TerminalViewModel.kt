package dev.sumi.terminal.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import dev.sumi.terminal.perf.PerformanceManager
import dev.sumi.terminal.service.TerminalSession
import dev.sumi.terminal.service.TerminalSessionManager
import dev.sumi.terminal.terminal.KeyEncoder
import dev.sumi.terminal.terminal.Mods
import dev.sumi.terminal.terminal.TermKey
import dev.sumi.terminal.terminal.TerminalBuffer.Selection
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

private const val MAX_PASTE_CHARS = 256_000

data class TerminalUiState(
    val sessionId: Int = 0,
    val frame: Long = 0,
    val inputReset: Long = 0,
    val pendingPaste: String? = null,
    val ctrl: Boolean = false,
    val alt: Boolean = false,
    val shift: Boolean = false,
    val selecting: Boolean = false,
    val selection: Selection? = null,
    val scrollOffset: Int = 0,      // linhas acima do fim
    val keepScreenOn: Boolean = false,
    val alive: Boolean = true,
    val exitCode: Int? = null,
    val canUndo: Boolean = false,
    val canRedo: Boolean = false,
)

sealed interface TerminalIntent {
    data class TextDelta(val deleted: Int, val inserted: String) : TerminalIntent
    data class Key(val key: TermKey) : TerminalIntent
    data class Resize(val rows: Int, val cols: Int) : TerminalIntent
    data class Scroll(val lines: Int) : TerminalIntent
    data class Paste(val text: String) : TerminalIntent
    data object ConsumePaste : TerminalIntent
    data class BeginSelection(val row: Int?, val col: Int?) : TerminalIntent
    data class MoveSelection(val dRow: Int, val dCol: Int) : TerminalIntent
    data class ExtendSelection(val row: Int, val col: Int) : TerminalIntent
    data class MoveHandle(val start: Boolean, val row: Int, val col: Int) : TerminalIntent
    data class SelectWord(val row: Int, val col: Int) : TerminalIntent
    data object SelectAll : TerminalIntent
    data object ToggleBlock : TerminalIntent
    data object Copy : TerminalIntent
    data object Cut : TerminalIntent
    data object DeleteBlock : TerminalIntent
    data object ExitSelection : TerminalIntent
    data object ToggleCtrl : TerminalIntent
    data object ToggleAlt : TerminalIntent
    data object ToggleShift : TerminalIntent
    data object Undo : TerminalIntent
    data object Redo : TerminalIntent
    data object RequestPaste : TerminalIntent
    data object ToggleKeepScreenOn : TerminalIntent
    data object NewTab : TerminalIntent
    data class CloseTab(val id: Int) : TerminalIntent
    data class SelectTab(val id: Int) : TerminalIntent
}

sealed interface TerminalEffect {
    data class CopyToClipboard(val text: String) : TerminalEffect
    data object ReadClipboard : TerminalEffect
}

@HiltViewModel
class TerminalViewModel @Inject constructor(
    private val sessions: TerminalSessionManager,
    private val perf: PerformanceManager,
) : ViewModel() {

    /** Estado de UI que pertence a cada aba (rolagem, seleção, modificadores, undo/redo). */
    private class Local {
        var ui = TerminalUiState()
        val undo = ArrayDeque<String>()
        val redo = ArrayDeque<String>()
    }

    private val locals = HashMap<Int, Local>()
    private var lastRows = 24
    private var lastCols = 80
    private var frameJob: Job? = null

    private var session: TerminalSession = sessions.current ?: sessions.newSession()
    private var local: Local = locals.getOrPut(session.id) { Local() }

    private val _state = MutableStateFlow(local.ui.copy(sessionId = session.id))
    val state: StateFlow<TerminalUiState> = _state.asStateFlow()
    private val _effects = MutableSharedFlow<TerminalEffect>(extraBufferCapacity = 8)
    val effects: SharedFlow<TerminalEffect> = _effects.asSharedFlow()

    val tabs: StateFlow<List<TerminalSession>> = sessions.sessions
    val activeId: StateFlow<Int> = sessions.activeId

    val buffer get() = session.buffer

    private val undoStack get() = local.undo
    private val redoStack get() = local.redo

    init {
        observe()
        viewModelScope.launch {
            sessions.activeId.collect { id -> if (id != 0 && id != session.id) switchTo(id) }
        }
    }

    private fun switchTo(id: Int) {
        val next = sessions.sessions.value.firstOrNull { it.id == id } ?: return
        local.ui = _state.value
        session = next
        local = locals.getOrPut(id) { Local() }
        next.resize(lastRows, lastCols)
        _state.value = local.ui.copy(
            sessionId = id, frame = next.frames.value, alive = next.alive.value, exitCode = next.exitCode.value,
        )
        observe()
    }

    private fun observe() {
        frameJob?.cancel()
        val s = session
        frameJob = viewModelScope.launch {
            s.frames.collect { // StateFlow já é conflated: quadros intermediários são descartados
                _state.update { st -> st.copy(frame = it, alive = s.alive.value, exitCode = s.exitCode.value) }
                delay(perf.frameIntervalMs.value) // throttle térmico
            }
        }
    }

    private fun closeTab(id: Int) {
        locals.remove(id)
        sessions.close(id)
        if (sessions.sessions.value.isEmpty()) sessions.newSession(lastRows, lastCols)
    }

    fun dispatch(i: TerminalIntent) {
        when (i) {
            is TerminalIntent.TextDelta -> textDelta(i)
            is TerminalIntent.Key -> key(i.key)
            is TerminalIntent.Resize -> { lastRows = i.rows; lastCols = i.cols; session.resize(i.rows, i.cols) }
            is TerminalIntent.Scroll -> _state.update {
                it.copy(scrollOffset = (it.scrollOffset + i.lines).coerceIn(0, maxOf(0, buffer.totalLines - buffer.rows)))
            }
                is TerminalIntent.Paste -> {
                    // Paste envia apenas bytes para o readline; newline fica protegido por bracketed paste.
                    paste(i.text)
                    _state.update { it.copy(inputReset = it.inputReset + 1, pendingPaste = null) }
                }
                TerminalIntent.ConsumePaste -> Unit
            is TerminalIntent.BeginSelection -> beginSelection(i)
            is TerminalIntent.MoveSelection -> moveSelection(i.dRow, i.dCol)
            is TerminalIntent.ExtendSelection -> _state.update { s ->
                val sel = s.selection ?: return@update s
                s.copy(selection = sel.copy(headRow = i.row.clampRow(), headCol = i.col.clampCol()))
            }
            is TerminalIntent.MoveHandle -> _state.update { s ->
                val sel = s.selection ?: return@update s
                val anchorFirst = sel.anchorRow < sel.headRow || (sel.anchorRow == sel.headRow && sel.anchorCol <= sel.headCol)
                val row = i.row.clampRow(); val col = i.col.clampCol()
                s.copy(selection = if (i.start == anchorFirst) sel.copy(anchorRow = row, anchorCol = col) else sel.copy(headRow = row, headCol = col))
            }
            is TerminalIntent.SelectWord -> {
                val row = i.row.clampRow()
                val (a, b) = buffer.wordBounds(row, i.col)
                _state.update { it.copy(selecting = true, selection = Selection(row, a, row, b, block = false)) }
            }
            TerminalIntent.SelectAll -> {
                val last = buffer.lastContentRow()
                _state.update { it.copy(selecting = true, selection = Selection(0, 0, last, buffer.cols - 1, block = false)) }
            }
            TerminalIntent.ToggleBlock -> _state.update { s -> s.copy(selection = s.selection?.copy(block = !s.selection.block)) }
            TerminalIntent.Copy -> selectionAction(copy = true, clear = false)
            TerminalIntent.Cut -> selectionAction(copy = true, clear = true)
            TerminalIntent.DeleteBlock -> selectionAction(copy = false, clear = true)
            TerminalIntent.ExitSelection -> _state.update { it.copy(selecting = false, selection = null) }
            TerminalIntent.ToggleCtrl -> _state.update { it.copy(ctrl = !it.ctrl) }
            TerminalIntent.ToggleAlt -> _state.update { it.copy(alt = !it.alt) }
            TerminalIntent.ToggleShift -> _state.update { it.copy(shift = !it.shift) }
            TerminalIntent.Undo -> undo()
            TerminalIntent.Redo -> redo()
            TerminalIntent.RequestPaste -> _effects.tryEmit(TerminalEffect.ReadClipboard)
            TerminalIntent.ToggleKeepScreenOn -> _state.update { it.copy(keepScreenOn = !it.keepScreenOn) }
            TerminalIntent.NewTab -> sessions.newSession(lastRows, lastCols)
            is TerminalIntent.CloseTab -> closeTab(i.id)
            is TerminalIntent.SelectTab -> sessions.select(i.id)
        }
    }

    private fun mods(): Mods = _state.value.let { Mods(it.ctrl, it.alt, it.shift) }
    private fun consumeMods() = _state.update { it.copy(ctrl = false, alt = false, shift = false) }
    private fun send(b: ByteArray) { session.write(b); _state.update { it.copy(scrollOffset = 0) } }

    private fun textDelta(d: TerminalIntent.TextDelta) {
        val m = mods()
        if (d.deleted > 0) send(ByteArray(d.deleted) { 0x7F })
        if (d.inserted.isNotEmpty()) {
            val inserted = d.inserted
            // Alguns IMEs móveis devolvem as setas como texto ([A/[B ou ESC[A/ESC[B)
            // em vez de um KeyEvent. Nunca deixe esses bytes contaminarem o prompt.
            val arrow = when (inserted) {
                "\u001B[A", "[A" -> TermKey.UP
                "\u001B[B", "[B" -> TermKey.DOWN
                "\u001B[C", "[C" -> TermKey.RIGHT
                "\u001B[D", "[D" -> TermKey.LEFT
                else -> null
            }
            if (arrow != null) {
                send(KeyEncoder.encode(arrow, m, buffer.appCursorKeys))
            } else {
                send(KeyEncoder.encodeText(inserted, m))
                if (!m.ctrl) { undoStack.addLast(inserted); redoStack.clear() }
            }
            if (m.any) consumeMods()
            publishUndo()
        }
    }

    private fun key(k: TermKey) {
        val s = _state.value
        if (s.selecting) {
            when (k) {
                TermKey.UP -> moveSelection(-1, 0)
                TermKey.DOWN -> moveSelection(1, 0)
                TermKey.LEFT -> moveSelection(0, -1)
                TermKey.RIGHT -> moveSelection(0, 1)
                TermKey.PGUP -> moveSelection(-10, 0)
                TermKey.PGDN -> moveSelection(10, 0)
                TermKey.HOME -> moveSelection(0, -buffer.cols)
                TermKey.END -> moveSelection(0, buffer.cols)
                TermKey.INS -> dispatch(TerminalIntent.ToggleBlock)
                TermKey.ESC -> dispatch(TerminalIntent.ExitSelection)
                TermKey.ENTER -> dispatch(TerminalIntent.Copy)
                else -> {}
            }
            return
        }
        val m = mods()
        send(KeyEncoder.encode(k, m, buffer.appCursorKeys))
        if (k == TermKey.ENTER) { undoStack.clear(); redoStack.clear(); publishUndo() }
        if (k == TermKey.ENTER || k == TermKey.UP || k == TermKey.DOWN || k == TermKey.LEFT || k == TermKey.RIGHT) {
            // O campo IME é invisível e não pode carregar o comando anterior para o próximo.
            _state.update { it.copy(inputReset = it.inputReset + 1) }
        }
        if (k == TermKey.BACKSPACE) { undoStack.removeLastOrNull()?.let { /* chunk já foi apagado manualmente */ }; publishUndo() }
        if (m.any) consumeMods()
    }

    private fun paste(text: String) {
        if (text.isEmpty()) return
        // Clipboard pode trazer CRLF/CR. O PTY deve receber cada quebra como LF real;
        // nunca removemos nem substituímos quebras por espaços.
        val normalized = text.replace("\r\n", "\n").replace('\r', '\n')
        // Protege o writer e o processo contra colagens acidentais gigantes.
        val safe = normalized.take(MAX_PASTE_CHARS)
        // Bash/readline usa bracketed paste para manter blocos inteiros no buffer,
        // sem executar cada linha nem fundir comandos durante a entrega pelo PTY.
        val needsBracketedPaste = safe.indexOf('\n') >= 0 || safe.indexOf('\r') >= 0
        val payload = if (buffer.bracketedPaste || needsBracketedPaste) "\u001B[200~$safe\u001B[201~" else safe
        send(payload.toByteArray(Charsets.UTF_8))
    }


    private fun undo() {
        val chunk = undoStack.removeLastOrNull() ?: return
        send(ByteArray(chunk.length) { 0x7F }); redoStack.addLast(chunk); publishUndo()
    }

    private fun redo() {
        val chunk = redoStack.removeLastOrNull() ?: return
        send(chunk.toByteArray()); undoStack.addLast(chunk); publishUndo()
    }

    private fun publishUndo() = _state.update { it.copy(canUndo = undoStack.isNotEmpty(), canRedo = redoStack.isNotEmpty()) }

    // ---------- Seleção ----------
    private fun beginSelection(i: TerminalIntent.BeginSelection) {
        val row = i.row ?: buffer.cursorAbsRow()
        val col = i.col ?: buffer.curCol
        _state.update { it.copy(selecting = true, selection = Selection(row, col, row, col, block = false)) }
    }

    private fun Int.clampRow() = coerceIn(0, buffer.totalLines - 1)
    private fun Int.clampCol() = coerceIn(0, buffer.cols - 1)

    private fun moveSelection(dRow: Int, dCol: Int) = _state.update { s ->
        val sel = s.selection ?: return@update s
        val total = buffer.totalLines
        val row = (sel.headRow + dRow).coerceIn(0, total - 1)
        val col = (sel.headCol + dCol).coerceIn(0, buffer.cols - 1)
        // Mantém a cabeça visível: janela = [total - rows - offset, total - offset)
        val top = total - buffer.rows - s.scrollOffset
        val offset = when {
            row < top -> total - buffer.rows - row
            row >= top + buffer.rows -> total - row - 1
            else -> s.scrollOffset
        }.coerceIn(0, maxOf(0, total - buffer.rows))
        s.copy(selection = sel.copy(headRow = row, headCol = col), scrollOffset = offset)
    }

    private fun selectionAction(copy: Boolean, clear: Boolean) {
        val sel = _state.value.selection ?: return
        if (copy) _effects.tryEmit(TerminalEffect.CopyToClipboard(buffer.extract(sel)))
        if (clear) buffer.clearSelection(sel)
        _state.update { it.copy(selecting = false, selection = null, frame = it.frame + 1) }
    }
}
