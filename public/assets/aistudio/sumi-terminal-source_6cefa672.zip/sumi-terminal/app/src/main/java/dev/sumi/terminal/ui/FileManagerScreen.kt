package dev.sumi.terminal.ui

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.ui.window.Dialog
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import coil.compose.AsyncImage
import coil.request.ImageRequest
import dev.sumi.terminal.files.FileOps
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class SortKey { NAME, DATE }

/** Área de transferência do gerenciador: vive no processo, então sobrevive à troca de abas. */
object FileClipboard {
    var files by mutableStateOf<List<File>>(emptyList())
    var cut by mutableStateOf(false)
}

private data class FileItem(
    val file: File, val isDir: Boolean, val isLink: Boolean, val size: Long, val modified: Long, val isImage: Boolean,
)

private sealed interface FileDialog {
    data class Rename(val file: File) : FileDialog
    data object NewFolder : FileDialog
    data object NewFile : FileDialog
    data class Delete(val files: List<File>) : FileDialog
}

private val imageExt = setOf("jpg", "jpeg", "png", "webp", "gif", "bmp", "heic", "heif")

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun FileManagerScreen(rootfs: File) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val roots = remember(rootfs) {
        listOf(
            "Armazenamento" to "/storage/emulated/0",
            "App data" to ctx.dataDir.absolutePath,
            "Arch (rootfs)" to rootfs.absolutePath,
            "Raiz /" to "/",
        )
    }

    var cwd by rememberSaveable { mutableStateOf("/storage/emulated/0") }
    var sortKey by rememberSaveable { mutableStateOf(SortKey.NAME) }
    var ascending by rememberSaveable { mutableStateOf(true) }
    var showHidden by rememberSaveable { mutableStateOf(true) }
    var selected by remember { mutableStateOf(setOf<String>()) }
    var refresh by remember { mutableIntStateOf(0) }
    var message by remember { mutableStateOf<String?>(null) }
    var listError by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var dialog by remember { mutableStateOf<FileDialog?>(null) }
    var preview by remember { mutableStateOf<File?>(null) }
    var editorFile by remember { mutableStateOf<File?>(null) }

    fun hasAllFiles() = Build.VERSION.SDK_INT < 30 || Environment.isExternalStorageManager()
    var allFiles by remember { mutableStateOf(hasAllFiles()) }
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    DisposableEffect(lifecycle) {
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_RESUME) { allFiles = hasAllFiles(); refresh++ }
        }
        lifecycle.addObserver(obs)
        onDispose { lifecycle.removeObserver(obs) }
    }

    val items by produceState(emptyList<FileItem>(), cwd, sortKey, ascending, showHidden, refresh) {
        value = withContext(Dispatchers.IO) {
            val dir = File(cwd)
            val children = dir.listFiles()
            if (children == null) {
                listError = if (dir.exists()) "Sem permissão para listar esta pasta" else "Pasta inexistente"
                emptyList()
            } else {
                listError = null
                val mapped = children
                    .filter { showHidden || !it.name.startsWith(".") }
                    .map {
                        val link = java.nio.file.Files.isSymbolicLink(it.toPath())
                        FileItem(
                            it, it.isDirectory, link, if (it.isFile) it.length() else 0L, it.lastModified(),
                            it.extension.lowercase() in imageExt,
                        )
                    }
                val cmp: Comparator<FileItem> = when (sortKey) {
                    SortKey.NAME -> compareBy(String.CASE_INSENSITIVE_ORDER) { it.file.name }
                    SortKey.DATE -> compareBy { it.modified }
                }
                val (dirs, files) = mapped.partition { it.isDir }
                val order = if (ascending) cmp else cmp.reversed()
                dirs.sortedWith(order) + files.sortedWith(order)
            }
        }
    }

    LaunchedEffect(message) { if (message != null) { delay(4000); message = null } }

    fun runOp(block: () -> Unit) {
        scope.launch {
            busy = true
            try { withContext(Dispatchers.IO) { block() } }
            catch (e: Throwable) { message = "Falhou: ${e.message ?: e::class.java.simpleName}" }
            finally { busy = false; selected = emptySet(); refresh++ }
        }
    }

    val rootPaths = remember(roots) { roots.map { it.second }.toSet() }
    val canGoUp = cwd !in rootPaths && File(cwd).parentFile != null
    BackHandler(enabled = selected.isNotEmpty() || canGoUp) {
        if (selected.isNotEmpty()) selected = emptySet()
        else File(cwd).parentFile?.let { cwd = it.absolutePath }
    }

    Column(Modifier.fillMaxSize().background(Sumi.Sumi1)) {
        LazyRow(Modifier.fillMaxWidth().padding(vertical = 6.dp), contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(roots) { (label, path) ->
                val active = cwd == path || cwd.startsWith(path.trimEnd('/') + "/") && path != "/"
                Chip(label, active) { cwd = path; selected = emptySet() }
            }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(
                "↑", color = if (canGoUp) Sumi.Paper else Sumi.Hairline, fontSize = 18.sp, fontFamily = Sumi.Mono,
                modifier = Modifier.clickable(enabled = canGoUp) { File(cwd).parentFile?.let { cwd = it.absolutePath; selected = emptySet() } }
                    .padding(end = 12.dp, top = 6.dp, bottom = 6.dp),
            )
            Text(cwd, color = Sumi.Muted, fontSize = 12.sp, fontFamily = Sumi.Mono, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically,
        ) {
            SortChip("Nome", sortKey == SortKey.NAME, ascending) {
                if (sortKey == SortKey.NAME) ascending = !ascending else { sortKey = SortKey.NAME; ascending = true }
            }
            SortChip("Data", sortKey == SortKey.DATE, ascending) {
                if (sortKey == SortKey.DATE) ascending = !ascending else { sortKey = SortKey.DATE; ascending = false }
            }
            Box(Modifier.weight(1f))
            Chip(if (showHidden) "ocultos: sim" else "ocultos: não", false) { showHidden = !showHidden }
            Chip("+ pasta", false) { dialog = FileDialog.NewFolder }
            Chip("+ arquivo", false) { dialog = FileDialog.NewFile }
        }
        HorizontalDivider(color = Sumi.Hairline, thickness = Sumi.HairlineWidth)

        val needsPerm = !allFiles && (cwd.startsWith("/storage") || cwd.startsWith("/sdcard") || cwd.startsWith("/mnt"))
        if (needsPerm) Banner("Permita o acesso a todos os arquivos para gerenciar o armazenamento.", "permitir") {
            ctx.startActivity(
                Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:${ctx.packageName}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            )
        }
        listError?.let { Banner(it, null, null) }
        message?.let { Banner(it, null, null) }
        if (busy) Banner("Processando…", null, null)

        LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
            items(items, key = { it.file.path }) { item ->
                val isSel = item.file.path in selected
                Row(
                    Modifier.fillMaxWidth()
                        .background(if (isSel) Sumi.Aizome else Sumi.Sumi1)
                        .combinedClickable(
                            onClick = {
                                when {
                                    selected.isNotEmpty() -> selected = if (isSel) selected - item.file.path else selected + item.file.path
                                    item.isDir -> { cwd = item.file.absolutePath }
                                    item.isImage -> preview = item.file
                                    else -> editorFile = item.file
                                }
                            },
                            onLongClick = { selected = if (isSel) selected - item.file.path else selected + item.file.path },
                        )
                        .padding(horizontal = 16.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Thumb(item)
                    Column(Modifier.weight(1f).padding(start = 12.dp)) {
                        Text(item.file.name + if (item.isLink) "  →" else "", color = Sumi.Paper, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            (if (item.isDir) "pasta" else fmtSize(item.size)) + "  ·  " + fmtDate(item.modified),
                            color = Sumi.Muted, fontSize = 11.sp, fontFamily = Sumi.Mono,
                        )
                    }
                }
                HorizontalDivider(color = Sumi.Hairline, thickness = Sumi.HairlineWidth)
            }
        }

        val clipCount = FileClipboard.files.size
        if (selected.isNotEmpty() || clipCount > 0) {
            Row(
                Modifier.fillMaxWidth().background(Sumi.Sumi2).navigationBarsPadding()
                    .horizontalScroll(androidx.compose.foundation.rememberScrollState())
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                if (selected.isNotEmpty()) {
                    Text("${selected.size}", color = Sumi.Paper, fontFamily = Sumi.Mono, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 8.dp))
                    ActionText("copiar") { FileClipboard.files = selected.map(::File); FileClipboard.cut = false; selected = emptySet(); message = "Copiado para a área de transferência" }
                    ActionText("mover") { FileClipboard.files = selected.map(::File); FileClipboard.cut = true; selected = emptySet(); message = "Marcado para mover" }
                    if (selected.size == 1) ActionText("renomear") { dialog = FileDialog.Rename(File(selected.first())) }
                    ActionText("excluir", danger = true) { dialog = FileDialog.Delete(selected.map(::File)) }
                    ActionText("limpar") { selected = emptySet() }
                } else {
                    Text("${if (FileClipboard.cut) "mover" else "copiar"} $clipCount", color = Sumi.Paper, fontFamily = Sumi.Mono, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 8.dp))
                    ActionText("colar aqui") {
                        val files = FileClipboard.files; val cut = FileClipboard.cut; val target = File(cwd)
                        runOp { files.forEach { if (cut) FileOps.move(it, target) else FileOps.copy(it, target) } }
                        if (cut) FileClipboard.files = emptyList()
                    }
                    ActionText("cancelar") { FileClipboard.files = emptyList() }
                }
            }
        }
    }

    when (val d = dialog) {
        is FileDialog.Rename -> NameDialog("Renomear", d.file.name, "renomear", { dialog = null }) { name ->
            dialog = null; runOp { FileOps.rename(d.file, name) }
        }
        FileDialog.NewFolder -> NameDialog("Nova pasta", "", "criar", { dialog = null }) { name ->
            dialog = null; runOp { FileOps.mkdir(File(cwd), name) }
        }
        FileDialog.NewFile -> NameDialog("Novo arquivo", "script.py", "criar e editar", { dialog = null }) { name ->
            dialog = null
            val target = File(cwd, name.trim())
            editorFile = target
            runOp { FileOps.createFile(File(cwd), name) }
        }
        is FileDialog.Delete -> AlertDialog(
            onDismissRequest = { dialog = null },
            title = { Text("Excluir ${d.files.size} item(ns)?") },
            text = { Text("Esta ação não pode ser desfeita.") },
            confirmButton = { TextButton({ dialog = null; runOp { d.files.forEach(FileOps::delete) } }) { Text("Excluir", color = Sumi.Kurenai) } },
            dismissButton = { TextButton({ dialog = null }) { Text("Cancelar") } },
        )
        null -> {}
    }

    editorFile?.let { f ->
        Dialog(onDismissRequest = { editorFile = null }) {
            Box(Modifier.fillMaxSize()) { TextEditorScreen(f) { editorFile = null } }
        }
    }

    preview?.let { f ->
        AlertDialog(
            onDismissRequest = { preview = null },
            title = { Text(f.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 14.sp) },
            text = {
                AsyncImage(
                    model = ImageRequest.Builder(ctx).data(f).size(1600).crossfade(true).build(),
                    contentDescription = f.name, contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxWidth(),
                )
            },
            confirmButton = { TextButton({ preview = null }) { Text("Fechar") } },
        )
    }
}

@Composable
private fun Thumb(item: FileItem) {
    val shape = androidx.compose.foundation.shape.RoundedCornerShape(2.dp)
    if (item.isImage) {
        AsyncImage(
            model = ImageRequest.Builder(LocalContext.current).data(item.file).size(128).crossfade(true).build(),
            contentDescription = item.file.name, contentScale = ContentScale.Crop,
            modifier = Modifier.size(40.dp).clip(shape),
        )
    } else {
        Box(Modifier.size(40.dp).border(Sumi.HairlineWidth, if (item.isDir) Sumi.Muted else Sumi.Hairline, shape), contentAlignment = Alignment.Center) {
            Text(
                if (item.isDir) "▰" else item.file.extension.take(4).uppercase().ifEmpty { "•" },
                color = if (item.isDir) Sumi.Paper else Sumi.Muted, fontSize = 13.sp, fontFamily = Sumi.Mono,
            )
        }
    }
}

@Composable
private fun Chip(label: String, active: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.border(Sumi.HairlineWidth, if (active) Sumi.Paper else Sumi.Hairline).clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 5.dp),
    ) { Text(label, color = if (active) Sumi.Paper else Sumi.Muted, fontSize = 12.sp, fontFamily = Sumi.Mono) }
}

@Composable
private fun SortChip(label: String, active: Boolean, ascending: Boolean, onClick: () -> Unit) =
    Chip(label + if (active) (if (ascending) " ▲" else " ▼") else "", active, onClick)

@Composable
private fun ActionText(label: String, danger: Boolean = false, onClick: () -> Unit) {
    Text(
        label, color = if (danger) Sumi.Kurenai else Sumi.Shironeri, fontSize = 12.sp, fontFamily = Sumi.Mono,
        modifier = Modifier
            .background(if (danger) Sumi.Kurenai.copy(alpha = 0.10f) else Sumi.Hairline.copy(alpha = 0.45f), androidx.compose.foundation.shape.RoundedCornerShape(7.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 9.dp), 
    )
}

@Composable
private fun Banner(text: String, action: String?, onAction: (() -> Unit)?) {
    Row(Modifier.fillMaxWidth().background(Sumi.Sumi2).padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(text, color = Sumi.Shironeri, fontSize = 12.sp, modifier = Modifier.weight(1f))
        if (action != null && onAction != null) Text(action, color = Sumi.Paper, fontFamily = Sumi.Mono, fontSize = 12.sp, modifier = Modifier.clickable(onClick = onAction).padding(start = 12.dp))
    }
}

@Composable
private fun NameDialog(title: String, initial: String, confirm: String, onDismiss: () -> Unit, onOk: (String) -> Unit) {
    var text by remember { mutableStateOf(initial) }
    val valid by remember { derivedStateOf { text.isNotBlank() && !text.contains('/') } }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { OutlinedTextField(text, { text = it }, singleLine = true) },
        confirmButton = { TextButton({ onOk(text) }, enabled = valid) { Text(confirm) } },
        dismissButton = { TextButton(onDismiss) { Text("Cancelar") } },
    )
}

private fun fmtSize(b: Long): String = when {
    b < 1024 -> "$b B"
    b < 1024 * 1024 -> "%.1f KB".format(Locale.US, b / 1024.0)
    b < 1024L * 1024 * 1024 -> "%.1f MB".format(Locale.US, b / 1048576.0)
    else -> "%.2f GB".format(Locale.US, b / 1073741824.0)
}

private fun fmtDate(ms: Long): String = SimpleDateFormat("dd/MM/yy HH:mm", Locale.getDefault()).format(Date(ms))
