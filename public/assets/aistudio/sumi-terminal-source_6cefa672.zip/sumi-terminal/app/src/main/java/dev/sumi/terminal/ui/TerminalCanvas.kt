package dev.sumi.terminal.ui

import android.graphics.Paint
import android.graphics.Typeface
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.AwaitPointerEventScope
import androidx.compose.ui.input.pointer.PointerId
import androidx.compose.ui.input.pointer.PointerInputChange
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.res.ResourcesCompat
import dev.sumi.terminal.R
import dev.sumi.terminal.terminal.TerminalBuffer
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlinx.coroutines.withTimeoutOrNull

private const val HANDLE_DP = 7f
private const val DOUBLE_TAP_MS = 300L

@Composable
fun TerminalCanvas(vm: TerminalViewModel, state: TerminalUiState, onTap: () -> Unit) {
    val density = LocalDensity.current
    val context = LocalContext.current
    val haptic = LocalHapticFeedback.current
    val currentOnTap by rememberUpdatedState(onTap)

    val textPx = with(density) { 13.sp.toPx() }
    val regular = remember { ResourcesCompat.getFont(context, R.font.jetbrains_mono_regular) ?: Typeface.MONOSPACE }
    val bold = remember { ResourcesCompat.getFont(context, R.font.jetbrains_mono_bold) ?: Typeface.DEFAULT_BOLD }
    val paint = remember(textPx) {
        Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = regular; textSize = textPx; letterSpacing = 0f }
    }
    // JetBrains Mono tem avanço fixo de 0,6 em; a medição só vale se concordar com isso.
    val cellW = remember(paint) {
        val measured = paint.measureText("0")
        val expected = textPx * 0.6f
        if (abs(measured - expected) < textPx * 0.08f) measured else expected
    }
    val fm = remember(paint) { paint.fontMetrics }
    val cellH = remember(paint) { fm.descent - fm.ascent }
    val handleR = with(density) { HANDLE_DP.dp.toPx() }
    val bgPaint = remember { Paint() }
    val selPaint = remember { Paint().apply { color = Sumi.Kinari.toArgb() } }
    val handlePaint = remember { Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Sumi.Kinari.toArgb() } }
    val buffer = vm.buffer
    var size by remember { mutableStateOf(IntSize.Zero) }

    Box(Modifier.fillMaxSize().background(TerminalAppearance.scaledBackground())) {
        TerminalAppearance.backgroundImage?.let { image ->
            androidx.compose.foundation.Image(
                bitmap = image, contentDescription = null,
                modifier = Modifier.fillMaxSize().alpha(0.28f),
                contentScale = androidx.compose.ui.layout.ContentScale.Crop,
            )
        }
        Canvas(
            Modifier
                .fillMaxSize()
                .onSizeChanged { sz: IntSize ->
                    size = sz
                    val cols = (sz.width / cellW).toInt().coerceAtLeast(20)
                    val rows = (sz.height / cellH).toInt().coerceAtLeast(5)
                    vm.dispatch(TerminalIntent.Resize(rows, cols))
                }
                .pointerInput(cellW, cellH, buffer, handleR) {
                    val slop = viewConfiguration.touchSlop
                    val hitRadius = 28.dp.toPx()
                    var lastTapAt = 0L
                    var lastTapPos = Offset.Zero

                    fun firstRow(): Int =
                        (buffer.totalLines - buffer.rows - vm.state.value.scrollOffset).coerceAtLeast(0)

                    fun cellAt(p: Offset): IntArray {
                        val row = (firstRow() + (p.y / cellH).toInt()).coerceIn(0, buffer.totalLines - 1)
                        val col = (p.x / cellW).toInt().coerceIn(0, buffer.cols - 1)
                        return intArrayOf(row, col)
                    }

                    fun hitHandle(p: Offset): Int {
                        val sel = vm.state.value.selection ?: return 0
                        val (start, end) = handleCenters(buffer.selectionSpans(sel), firstRow(), cellW, cellH, handleR)
                        return when {
                            (p - start).getDistance() <= hitRadius -> 1
                            (p - end).getDistance() <= hitRadius -> 2
                            else -> 0
                        }
                    }

                    fun edgeScroll(y: Float) {
                        if (y < cellH) vm.dispatch(TerminalIntent.Scroll(1))
                        else if (y > size.height - cellH) vm.dispatch(TerminalIntent.Scroll(-1))
                    }

                    awaitEachGesture {
                        val down = awaitFirstDown(requireUnconsumed = false)

                        val handle = hitHandle(down.position)
                        if (handle != 0) {
                            down.consume()
                            trackPointer(down.id) { ch ->
                                val isStart = handle == 1
                                val y = ch.position.y + if (isStart) handleR * 1.5f else -handleR * 1.5f
                                val boundary = (ch.position.x / cellW).roundToInt()
                                val row = cellAt(Offset(0f, y))[0]
                                vm.dispatch(
                                    TerminalIntent.MoveHandle(
                                        start = isStart, row = row,
                                        col = (if (isStart) boundary else boundary - 1).coerceIn(0, buffer.cols - 1),
                                    ),
                                )
                                edgeScroll(ch.position.y)
                            }
                            return@awaitEachGesture
                        }

                        if (vm.state.value.selecting) {
                            val (r, c) = cellAt(down.position).let { it[0] to it[1] }
                            vm.dispatch(TerminalIntent.BeginSelection(r, c))
                            down.consume()
                            trackPointer(down.id) { ch ->
                                val p = cellAt(ch.position)
                                vm.dispatch(TerminalIntent.ExtendSelection(p[0], p[1]))
                                edgeScroll(ch.position.y)
                            }
                            return@awaitEachGesture
                        }

                        var released = false
                        var moved = false
                        val longPressed = withTimeoutOrNull(viewConfiguration.longPressTimeoutMillis) {
                            while (true) {
                                val ev = awaitPointerEvent()
                                val ch = ev.changes.firstOrNull { it.id == down.id }
                                if (ch == null || !ch.pressed) { released = true; return@withTimeoutOrNull }
                                if ((ch.position - down.position).getDistance() > slop) { moved = true; return@withTimeoutOrNull }
                            }
                        } == null

                        when {
                            longPressed -> {
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                val (r, c) = cellAt(down.position).let { it[0] to it[1] }
                                vm.dispatch(TerminalIntent.BeginSelection(r, c))
                                trackPointer(down.id) { ch ->
                                    val p = cellAt(ch.position)
                                    vm.dispatch(TerminalIntent.ExtendSelection(p[0], p[1]))
                                    edgeScroll(ch.position.y)
                                }
                            }
                            moved -> {
                                var acc = 0f
                                trackPointer(down.id) { ch ->
                                    acc += ch.positionChange().y
                                    val lines = (acc / cellH).toInt()
                                    if (lines != 0) { vm.dispatch(TerminalIntent.Scroll(lines)); acc -= lines * cellH }
                                }
                            }
                            released -> {
                                val now = System.currentTimeMillis()
                                if (now - lastTapAt < DOUBLE_TAP_MS && (down.position - lastTapPos).getDistance() < slop * 4) {
                                    val p = cellAt(down.position)
                                    vm.dispatch(TerminalIntent.SelectWord(p[0], p[1]))
                                    lastTapAt = 0L
                                } else {
                                    lastTapAt = now; lastTapPos = down.position
                                    currentOnTap()
                                }
                            }
                        }
                    }
                },
        ) {
            @Suppress("UNUSED_EXPRESSION") state.frame // lê o frame para invalidar o desenho
            val rows = buffer.rows; val cols = buffer.cols
            val total = buffer.totalLines
            val first = (total - rows - state.scrollOffset).coerceAtLeast(0)
            val spanList = state.selection?.let { buffer.selectionSpans(it) }.orEmpty()
            val spans = spanList.associateBy { it[0] }
            val selText = TerminalAppearance.background.toArgb()

            drawIntoCanvas { c ->
                val cv = c.nativeCanvas
                for (r in 0 until rows) {
                    val abs = first + r
                    if (abs >= total) break
                    val line = buffer.lineAt(abs)
                    val y = r * cellH
                    val sp = spans[abs]
                    for (col in 0 until minOf(cols, line.chars.size)) {
                        val inv = line.attr[col] and TerminalBuffer.ATTR_INVERSE != 0
                        val bg = if (inv) (line.fg[col].takeIf { it != 0 } ?: Sumi.Shironeri.toArgb()) else line.bg[col]
                        if (bg != 0) { bgPaint.color = bg; cv.drawRect(col * cellW, y, (col + 1) * cellW, y + cellH, bgPaint) }
                    }
                    if (sp != null) cv.drawRect(sp[1] * cellW, y, (sp[2] + 1) * cellW, y + cellH, selPaint)

                    var runStart = 0
                    while (runStart < cols) {
                        val fg0 = cellFg(line, runStart); val at0 = line.attr[runStart]
                        var end = runStart + 1
                        while (end < cols && cellFg(line, end) == fg0 && line.attr[end] == at0) end++
                        if (line.chars.slice(runStart until end).any { it != ' ' }) {
                            val isBold = at0 and TerminalBuffer.ATTR_BOLD != 0
                            paint.typeface = if (isBold) bold else regular
                            paint.isUnderlineText = at0 and TerminalBuffer.ATTR_UNDERLINE != 0
                            for (cc in runStart until end) {
                                if (line.chars[cc] == ' ') continue
                                val selected = sp != null && cc in sp[1]..sp[2]
                                paint.color = if (selected) selText else fg0
                                paint.alpha = if (!selected && at0 and TerminalBuffer.ATTR_DIM != 0) 140 else 255
                                // Um drawText por célula em col*cellW: texto, seleção e cursor compartilham a grade.
                                cv.drawText(line.chars, cc, 1, cc * cellW, y - fm.ascent, paint)
                            }
                        }
                        runStart = end
                    }
                }
                paint.typeface = regular; paint.isUnderlineText = false

                if (state.scrollOffset == 0 && buffer.cursorVisible && state.selection == null) {
                    val cursorAbs = buffer.cursorAbsRow()
                    val ccol = buffer.curCol.coerceIn(0, cols - 1)
                    val cy = (cursorAbs - first) * cellH
                    if (cy >= 0 && cursorAbs < total) {
                        drawRect(Sumi.Paper.copy(alpha = 0.85f), Offset(ccol * cellW, cy), Size(cellW, cellH))
                        val under = buffer.lineAt(cursorAbs).chars.getOrNull(ccol)
                        if (under != null && under != ' ') {
                            paint.color = Sumi.Sumi1.toArgb(); paint.alpha = 255
                            cv.drawText(charArrayOf(under), 0, 1, ccol * cellW, cy - fm.ascent, paint)
                        }
                    }
                }

                if (spanList.isNotEmpty()) {
                    val (start, end) = handleCenters(spanList, first, cellW, cellH, handleR)
                    val stem = handleR * 0.28f
                    cv.drawRect(start.x - stem, start.y, start.x + stem, start.y + handleR + cellH, handlePaint)
                    cv.drawRect(end.x - stem, end.y - handleR - cellH, end.x + stem, end.y, handlePaint)
                    cv.drawCircle(start.x, start.y, handleR, handlePaint)
                    cv.drawCircle(end.x, end.y, handleR, handlePaint)
                }
            }
        }

        SelectionPopup(vm, state, buffer, cellW, cellH, handleR, size)
    }
}

/** Centros das alças: início acima da primeira linha, fim abaixo da última. */
private fun handleCenters(spans: List<IntArray>, first: Int, cellW: Float, cellH: Float, r: Float): Pair<Offset, Offset> {
    val a = spans.first(); val b = spans.last()
    return Offset(a[1] * cellW, (a[0] - first) * cellH - r) to Offset((b[2] + 1) * cellW, (b[0] - first + 1) * cellH + r)
}

private suspend fun AwaitPointerEventScope.trackPointer(id: PointerId, onMove: (PointerInputChange) -> Unit) {
    while (true) {
        val ev = awaitPointerEvent()
        val ch = ev.changes.firstOrNull { it.id == id } ?: return
        if (!ch.pressed) return
        onMove(ch)
        ch.consume()
    }
}

@Composable
private fun SelectionPopup(
    vm: TerminalViewModel, state: TerminalUiState, buffer: TerminalBuffer,
    cellW: Float, cellH: Float, handleR: Float, size: IntSize,
) {
    val sel = state.selection ?: return
    if (size == IntSize.Zero) return
    val clipboard = androidx.compose.ui.platform.LocalClipboardManager.current
    val spans = remember(sel, state.frame) { buffer.selectionSpans(sel) }
    val first = (buffer.totalLines - buffer.rows - state.scrollOffset).coerceAtLeast(0)
    val a = spans.first(); val b = spans.last()
    val top = (a[0] - first) * cellH
    val bottom = (b[0] - first + 1) * cellH
    var pop by remember { mutableStateOf(IntSize.Zero) }
    val gap = with(LocalDensity.current) { 8.dp.toPx() }
    val xCenter = if (spans.size == 1) (a[1] + a[2] + 1) / 2f * cellW else size.width / 2f
    val x = (xCenter - pop.width / 2f).coerceIn(gap, (size.width - pop.width - gap).coerceAtLeast(gap))
    var y = top - 2 * handleR - pop.height - gap
    if (y < gap) y = bottom + 2 * handleR + gap
    y = y.coerceIn(gap, (size.height - pop.height - gap).coerceAtLeast(gap))
    val shape = RoundedCornerShape(10.dp)

    Row(
        Modifier
            .offset { IntOffset(x.roundToInt(), y.roundToInt()) }
            .onSizeChanged { pop = it }
            .shadow(10.dp, shape)
            .background(Sumi.Sumi2, shape)
            .border(Sumi.HairlineWidth, Sumi.Hairline, shape)
            .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        PopupAction("Copiar", primary = true) { vm.dispatch(TerminalIntent.Copy) }
        PopupAction("Colar") { clipboard.getText()?.text?.let { vm.dispatch(TerminalIntent.Paste(it)) } }
        PopupAction("Tudo") { vm.dispatch(TerminalIntent.SelectAll) }
        PopupAction("Desmarcar") { vm.dispatch(TerminalIntent.ExitSelection) }
    }
}

@Composable
private fun PopupAction(label: String, primary: Boolean = false, onClick: () -> Unit) {
    val shape = RoundedCornerShape(7.dp)
    Box(
        Modifier
            .height(40.dp)
            .background(if (primary) Sumi.Kinari else Sumi.Sumi1, shape)
            .clickable(role = Role.Button, onClick = onClick)
            .padding(horizontal = 14.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            label, color = if (primary) Sumi.Sumi1 else Sumi.Shironeri,
            fontFamily = Sumi.Mono, fontSize = 13.sp, fontWeight = FontWeight.Medium,
        )
    }
}

private fun cellFg(line: TerminalBuffer.Line, i: Int): Int {
    val inv = line.attr[i] and TerminalBuffer.ATTR_INVERSE != 0
    if (inv) return TerminalAppearance.background.toArgb()
    val ansi = line.fg[i]
    if (ansi != 0) return ansi
    if (TerminalAppearance.autoCommandColors) {
        val plain = line.chars.concatToString()
        if (plain.contains("error", ignoreCase = true) || plain.contains("failed", ignoreCase = true) || plain.contains("not found", ignoreCase = true)) return 0xFFFF5252.toInt()
        val token = plain.trimStart().takeWhile { !it.isWhitespace() }
        if (token.isNotEmpty()) {
            val palette = intArrayOf(0xFFB388FF.toInt(), 0xFF64B5F6.toInt(), 0xFF81C784.toInt(), 0xFFFF80AB.toInt(), 0xFFFFB74D.toInt(), 0xFF4DD0E1.toInt())
            return palette[(token.hashCode() and Int.MAX_VALUE) % palette.size]
        }
    }
    return TerminalAppearance.foreground.toArgb()
}
