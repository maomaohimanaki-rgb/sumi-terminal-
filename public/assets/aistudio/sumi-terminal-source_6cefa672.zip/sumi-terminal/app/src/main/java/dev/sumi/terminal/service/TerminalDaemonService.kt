package dev.sumi.terminal.service

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.net.LocalServerSocket
import android.net.LocalSocket
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import dagger.hilt.android.AndroidEntryPoint
import dev.sumi.terminal.MainActivity
import dev.sumi.terminal.perf.PerformanceManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStreamReader
import javax.inject.Inject

/**
 * Daemon em foreground (specialUse) à prova de remoção da lista de recentes:
 *  - START_STICKY: o sistema recria o serviço após morte do processo;
 *  - onTaskRemoved: agenda reinício via AlarmManager;
 *  - PARTIAL_WAKE_LOCK "APP:DAEMON_WAKELOCK" mantém a CPU ativa em Doze;
 *  - socket abstrato "dev.sumi.terminal.hook" recebe hooks de agentes/scripts.
 */
@AndroidEntryPoint
class TerminalDaemonService : Service() {

    @Inject lateinit var sessions: TerminalSessionManager
    @Inject lateinit var perf: PerformanceManager
    @Inject lateinit var dispatcher: AgentAlertDispatcher

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var wakeLock: PowerManager.WakeLock? = null
    private var socketJob: Job? = null
    private var server: LocalServerSocket? = null
    private val startedAt = SystemClock.elapsedRealtime()
    private lateinit var nm: NotificationManager

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        nm = getSystemService(NotificationManager::class.java)
        createChannels()
        perf.start()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIF_DAEMON, buildDaemonNotification())
        acquireWakeLock()
        if (socketJob == null) {
            socketJob = scope.launch { listenForHooks() }
            scope.launch { collectAlerts() }
            scope.launch { tickNotification() }
        }
        return START_STICKY
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        val restart = PendingIntent.getForegroundService(
            this, 1, Intent(this, TerminalDaemonService::class.java),
            PendingIntent.FLAG_ONE_SHOT or PendingIntent.FLAG_IMMUTABLE,
        )
        getSystemService(AlarmManager::class.java)
            .setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, SystemClock.elapsedRealtime() + 1_000, restart)
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        scope.cancel()
        runCatching { server?.close() }
        runCatching { if (wakeLock?.isHeld == true) wakeLock?.release() }
        perf.stop()
        super.onDestroy()
    }

    private fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return
        wakeLock = getSystemService(PowerManager::class.java)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "APP:DAEMON_WAKELOCK")
            .apply { setReferenceCounted(false); acquire() } // liberado em onDestroy
    }

    // ---------- Notificações ----------
    private fun createChannels() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        nm.createNotificationChannel(NotificationChannel(CH_DAEMON, "Daemon do terminal", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_ALERT, "Alertas de agentes e builds", NotificationManager.IMPORTANCE_HIGH))
    }

    private fun buildDaemonNotification(): Notification {
        val up = (SystemClock.elapsedRealtime() - startedAt) / 1000
        val rt = Runtime.getRuntime()
        val usedMb = (rt.totalMemory() - rt.freeMemory()) / (1024 * 1024)
        val s = sessions.current
        val status = when {
            s == null -> "sem sessão"
            s.alive.value -> "${sessions.sessions.value.size} sessão(ões), ativa: ${s.title}"
            else -> "sessão #${s.id} encerrada (exit ${s.exitCode.value})"
        }
        val text = "uptime %02d:%02d:%02d  |  heap %d MB  |  %s".format(up / 3600, up / 60 % 60, up % 60, usedMb, status)
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CH_DAEMON)
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .setContentTitle("Sumi Terminal")
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text + "\nthermal: ${perf.thermalStatus.value}"))
            .setOngoing(true).setOnlyAlertOnce(true).setContentIntent(open)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }

    private suspend fun tickNotification() {
        while (scope.isActive) {
            nm.notify(NOTIF_DAEMON, buildDaemonNotification())
            delay(5_000)
        }
    }

    private suspend fun collectAlerts() {
        dispatcher.events.collect { ev ->
            val (title, body, ok) = when (ev) {
                is AgentEvent.ProcessExit -> Triple(
                    if (ev.exitCode == 0) "Concluído (exit 0)" else "Falhou (exit ${ev.exitCode})",
                    ev.command, ev.exitCode == 0,
                )
                is AgentEvent.Hook -> Triple(if (ev.success) "Agente: sucesso" else "Agente: erro", ev.message, ev.success)
            }
            val open = PendingIntent.getActivity(this, 2, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
            val n = NotificationCompat.Builder(this, CH_ALERT)
                .setSmallIcon(if (ok) android.R.drawable.ic_dialog_info else android.R.drawable.ic_dialog_alert)
                .setContentTitle(title).setContentText(body)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true).setContentIntent(open).build()
            nm.notify(NOTIF_ALERT_BASE + (System.nanoTime() % 10_000).toInt(), n)
        }
    }

    // ---------- Socket local para hooks ----------
    // Dentro do proot: printf 'ok|build finalizado\n' | socat - ABSTRACT-CONNECT:dev.sumi.terminal.hook
    private suspend fun listenForHooks() = withContext(Dispatchers.IO) {
        try {
            val srv = LocalServerSocket(HOOK_SOCKET).also { server = it }
            while (isActive) {
                val client = srv.accept()
                launch { handleClient(client) }
            }
        } catch (_: Exception) { /* socket fechado em onDestroy */ }
    }

    private fun handleClient(client: LocalSocket) = client.use {
        BufferedReader(InputStreamReader(it.inputStream)).forEachLine { line ->
            val idx = line.indexOf('|')
            val status = if (idx > 0) line.substring(0, idx).trim().lowercase() else "ok"
            val msg = if (idx > 0) line.substring(idx + 1).trim() else line.trim()
            if (msg.isNotEmpty()) dispatcher.emit(AgentEvent.Hook(status == "ok" || status == "success", msg.take(200)))
        }
    }

    companion object {
        const val CH_DAEMON = "daemon"
        const val CH_ALERT = "agent_alerts"
        const val NOTIF_DAEMON = 1
        const val NOTIF_ALERT_BASE = 1000
        const val HOOK_SOCKET = "dev.sumi.terminal.hook"

        fun start(ctx: Context) {
            val i = Intent(ctx, TerminalDaemonService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) ctx.startForegroundService(i) else ctx.startService(i)
        }
    }
}
