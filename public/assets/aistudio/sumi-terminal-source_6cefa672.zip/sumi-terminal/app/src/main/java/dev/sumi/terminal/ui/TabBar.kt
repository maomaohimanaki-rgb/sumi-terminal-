package dev.sumi.terminal.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.sumi.terminal.service.TerminalSession

@Composable
fun TabBar(
    sessions: List<TerminalSession>,
    activeId: Int,
    onSelect: (Int) -> Unit,
    onClose: (Int) -> Unit,
    onNew: () -> Unit,
    onOpenFiles: () -> Unit,
    onAppearance: () -> Unit,
) {
    Row(Modifier.fillMaxWidth().height(36.dp).background(Sumi.Sumi2), verticalAlignment = Alignment.CenterVertically) {
        LazyRow(Modifier.weight(1f).fillMaxHeight()) {
            items(sessions, key = { it.id }) { s ->
                val alive by s.alive.collectAsState()
                val active = s.id == activeId
                Box(Modifier.fillMaxHeight().clickable { onSelect(s.id) }) {
                    Row(Modifier.fillMaxHeight().padding(start = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            s.title, fontSize = 12.sp, fontFamily = Sumi.Mono,
                            color = when { !alive -> Sumi.Kurenai; active -> Sumi.Paper; else -> Sumi.Muted },
                        )
                        Text(
                            "×", fontSize = 16.sp, color = Sumi.Muted,
                            modifier = Modifier.clickable { onClose(s.id) }.padding(horizontal = 10.dp, vertical = 6.dp),
                        )
                    }
                    if (active) Box(Modifier.align(Alignment.BottomStart).fillMaxWidth().height(1.5.dp).background(Sumi.Paper))
                }
            }
        }
        Text("+", fontSize = 20.sp, color = Sumi.Paper, modifier = Modifier.clickable(onClick = onNew).padding(horizontal = 14.dp))
        Text("tema", fontSize = 11.sp, fontFamily = Sumi.Mono, color = Sumi.Muted, modifier = Modifier.clickable(onClick = onAppearance).padding(horizontal = 10.dp, vertical = 8.dp))
        Box(Modifier.width(Sumi.HairlineWidth).height(16.dp).background(Sumi.Hairline))
        Text("arquivos", fontSize = 12.sp, fontFamily = Sumi.Mono, color = Sumi.Muted,
            modifier = Modifier.clickable(onClick = onOpenFiles).padding(horizontal = 12.dp))
    }
}
