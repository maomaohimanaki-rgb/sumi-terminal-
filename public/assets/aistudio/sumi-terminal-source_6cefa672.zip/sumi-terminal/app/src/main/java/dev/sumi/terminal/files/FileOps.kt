package dev.sumi.terminal.files

import java.io.File
import java.io.IOException
import java.nio.file.FileVisitResult
import java.nio.file.Files
import java.nio.file.LinkOption
import java.nio.file.Path
import java.nio.file.SimpleFileVisitor
import java.nio.file.attribute.BasicFileAttributes

/** Operações que nunca seguem symlinks (importante dentro do rootfs, onde há links absolutos). */
object FileOps {

    private fun exists(f: File) = Files.exists(f.toPath(), LinkOption.NOFOLLOW_LINKS)

    fun uniqueTarget(dir: File, name: String): File {
        var t = File(dir, name)
        if (!exists(t)) return t
        val dot = name.lastIndexOf('.').takeIf { it > 0 }
        val base = dot?.let { name.substring(0, it) } ?: name
        val ext = dot?.let { name.substring(it) } ?: ""
        var i = 1
        while (exists(t)) { t = File(dir, "$base (cópia${if (i > 1) " $i" else ""})$ext"); i++ }
        return t
    }

    private fun checkNotInside(dir: File, src: File) {
        val d = dir.canonicalPath; val s = src.canonicalPath
        if (src.isDirectory && (d == s || d.startsWith("$s/"))) {
            throw IOException("Não é possível colocar uma pasta dentro dela mesma")
        }
    }

    fun copy(src: File, dir: File): File {
        checkNotInside(dir, src)
        val dest = uniqueTarget(dir, src.name)
        copyTree(src.toPath(), dest.toPath())
        return dest
    }

    fun move(src: File, dir: File): File {
        if (src.parentFile?.canonicalPath == dir.canonicalPath) return src
        checkNotInside(dir, src)
        val dest = uniqueTarget(dir, src.name)
        if (!src.renameTo(dest)) { // entre sistemas de arquivos diferentes o rename falha: copia e apaga
            copyTree(src.toPath(), dest.toPath())
            delete(src)
        }
        return dest
    }

    fun rename(src: File, newName: String): File {
        val name = newName.trim()
        if (name.isEmpty() || name.contains('/') || name == "." || name == "..") throw IOException("Nome inválido")
        val dest = File(src.parentFile, name)
        if (exists(dest)) throw IOException("Já existe um item com esse nome")
        if (!src.renameTo(dest)) throw IOException("Não foi possível renomear")
        return dest
    }

    fun createFile(parent: File, name: String): File {
        val n = name.trim()
        if (n.isEmpty() || n.contains('/') || n == "." || n == "..") throw IOException("Nome inválido")
        val f = File(parent, n)
        if (exists(f)) throw IOException("Já existe um item com esse nome")
        if (!f.createNewFile()) throw IOException("Não foi possível criar o arquivo")
        return f
    }

    fun mkdir(parent: File, name: String): File {
        val n = name.trim()
        if (n.isEmpty() || n.contains('/')) throw IOException("Nome inválido")
        val d = File(parent, n)
        if (exists(d)) throw IOException("Já existe um item com esse nome")
        if (!d.mkdirs()) throw IOException("Não foi possível criar a pasta")
        return d
    }

    fun delete(f: File) {
        val p = f.toPath()
        if (!exists(f)) return
        Files.walkFileTree(p, object : SimpleFileVisitor<Path>() {
            override fun preVisitDirectory(dir: Path, attrs: BasicFileAttributes): FileVisitResult {
                dir.toFile().apply { setReadable(true); setWritable(true); setExecutable(true) }
                return FileVisitResult.CONTINUE
            }
            override fun visitFile(file: Path, attrs: BasicFileAttributes): FileVisitResult {
                Files.delete(file); return FileVisitResult.CONTINUE
            }
            override fun postVisitDirectory(dir: Path, exc: IOException?): FileVisitResult {
                Files.delete(dir); return FileVisitResult.CONTINUE
            }
        })
    }

    private fun copyTree(src: Path, dest: Path) {
        Files.walkFileTree(src, object : SimpleFileVisitor<Path>() {
            override fun preVisitDirectory(dir: Path, attrs: BasicFileAttributes): FileVisitResult {
                Files.createDirectories(dest.resolve(src.relativize(dir).toString()))
                return FileVisitResult.CONTINUE
            }
            override fun visitFile(file: Path, attrs: BasicFileAttributes): FileVisitResult {
                val t = dest.resolve(src.relativize(file).toString())
                when {
                    attrs.isSymbolicLink -> Files.createSymbolicLink(t, Files.readSymbolicLink(file))
                    attrs.isRegularFile -> Files.copy(file, t)
                }
                return FileVisitResult.CONTINUE
            }
        })
    }
}
