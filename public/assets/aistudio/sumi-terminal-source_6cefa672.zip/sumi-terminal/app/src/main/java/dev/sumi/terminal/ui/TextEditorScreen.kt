package dev.sumi.terminal.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

@Composable
fun TextEditorScreen(file: File, onClose: () -> Unit) {
    var value by remember(file) { mutableStateOf(TextFieldValue("")) }
    var loaded by remember(file) { mutableStateOf(false) }
    var dirty by remember(file) { mutableStateOf(false) }
    var status by remember { mutableStateOf("carregando") }
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current
    val scroll = rememberScrollState()

    LaunchedEffect(file) {
        val content = withContext(Dispatchers.IO) {
            runCatching { file.readText(Charsets.UTF_8) }.getOrDefault("")
        }
        value = TextFieldValue(content, TextRange(content.length))
        loaded = true
        status = "pronto"
    }

    fun save() {
        status = "salvando"
        // A gravação síncrona é disparada por uma ação explícita; o conteúdo é salvo em IO.
        scope.launch(Dispatchers.IO) {
            runCatching { file.writeText(value.text, Charsets.UTF_8) }
                .onSuccess { status = "salvo" }
                .onFailure { status = "erro ao salvar" }
            dirty = false
        }
    }

    Column(Modifier.fillMaxSize().background(Sumi.Sumi1)) {
        Row(
            Modifier.fillMaxWidth().background(Sumi.Sumi2).padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Text("‹", color = Sumi.Paper, fontSize = 24.sp, modifier = Modifier.clickable { onClose() })
            Column(Modifier.weight(1f)) {
                Text(file.name, color = Sumi.Paper, fontFamily = Sumi.Mono, fontSize = 14.sp, maxLines = 1)
                Text(status + if (dirty) " · alterado" else "", color = Sumi.Muted, fontFamily = Sumi.Mono, fontSize = 10.sp)
            }
            EditorAction("colar") {
                clipboard.getText()?.text?.let { pasted ->
                    val start = value.selection.min
                    val end = value.selection.max
                    value = value.copy(text = value.text.replaceRange(start, end, pasted), selection = TextRange(start + pasted.length))
                    dirty = true
                }
            }
            EditorAction("copiar") {
                val selected = value.text.substring(value.selection.min, value.selection.max)
                if (selected.isNotEmpty()) clipboard.setText(AnnotatedString(selected))
            }
            EditorAction("tudo") { value = value.copy(selection = TextRange(0, value.text.length)) }
            EditorAction("salvar", active = dirty) { save() }
        }
        if (loaded) {
            Box(Modifier.fillMaxSize().verticalScroll(scroll).padding(12.dp)) {
                BasicTextField(
                    value = value,
                    onValueChange = { value = it; dirty = true },
                    textStyle = androidx.compose.ui.text.TextStyle(color = TerminalAppearance.foreground, fontFamily = Sumi.Mono, fontSize = 12.sp, lineHeight = 18.sp),
                    cursorBrush = androidx.compose.ui.graphics.SolidColor(TerminalAppearance.accent),
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        }
    }
}

@Composable
private fun EditorAction(label: String, active: Boolean = false, onClick: () -> Unit) {
    Text(label, color = if (active) TerminalAppearance.accent else Sumi.Muted, fontFamily = Sumi.Mono, fontSize = 10.sp, modifier = Modifier.clickable(onClick = onClick).padding(4.dp))
}

private fun lineNumbers(text: String): String {
    val count = text.count { it == '\n' } + 1
    return (1..count).joinToString("\n") { it.toString().padStart(4, ' ') }
}
