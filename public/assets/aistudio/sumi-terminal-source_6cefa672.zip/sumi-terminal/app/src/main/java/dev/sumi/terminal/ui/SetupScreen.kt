package dev.sumi.terminal.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.sumi.terminal.install.InstallState

@Composable
fun SetupScreen(state: InstallState, onRetry: () -> Unit, onSkip: () -> Unit) {
    Column(
        Modifier.fillMaxSize().background(Sumi.Sumi1).statusBarsPadding().padding(28.dp),
        verticalArrangement = Arrangement.Center,
    ) {
        Text("準備", fontSize = 56.sp, color = Sumi.Hairline, fontFamily = Sumi.Sans)
        Spacer(Modifier.height(8.dp))
        Text("Configurando ambiente", fontSize = 20.sp, color = Sumi.Paper, fontFamily = Sumi.Sans)
        Spacer(Modifier.height(4.dp))
        Text(
            "Primeira execução: o app baixa e instala o Arch Linux sozinho. Mantenha a tela aberta e a internet ligada.",
            fontSize = 13.sp, color = Sumi.Muted, lineHeight = 19.sp,
        )
        Spacer(Modifier.height(28.dp))

        when (state) {
            is InstallState.Working -> {
                Text(state.phase.label, fontSize = 14.sp, color = Sumi.Shironeri, fontFamily = Sumi.Mono)
                Spacer(Modifier.height(12.dp))
                if (state.progress != null) {
                    LinearProgressIndicator(
                        progress = { state.progress.coerceIn(0f, 1f) },
                        modifier = Modifier.fillMaxWidth().height(2.dp),
                        color = Sumi.Paper, trackColor = Sumi.Hairline,
                    )
                } else {
                    LinearProgressIndicator(
                        modifier = Modifier.fillMaxWidth().height(2.dp),
                        color = Sumi.Paper, trackColor = Sumi.Hairline,
                    )
                }
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(state.detail, fontSize = 12.sp, color = Sumi.Muted, fontFamily = Sumi.Mono)
                    state.progress?.let {
                        Text("${(it * 100).toInt()}%", fontSize = 12.sp, color = Sumi.Muted, fontFamily = Sumi.Mono)
                    }
                }
            }
            is InstallState.Failed -> {
                Text("Não foi possível concluir", fontSize = 14.sp, color = Sumi.Kurenai, fontFamily = Sumi.Mono)
                Spacer(Modifier.height(6.dp))
                Text(state.message, fontSize = 12.sp, color = Sumi.Muted, lineHeight = 18.sp)
                Spacer(Modifier.height(18.dp))
                SetupButton("Tentar novamente", onRetry)
            }
            else -> Text("Preparando…", fontSize = 14.sp, color = Sumi.Shironeri, fontFamily = Sumi.Mono)
        }

        Spacer(Modifier.height(36.dp))
        Text(
            "usar apenas o shell do Android",
            fontSize = 12.sp, color = Sumi.Muted, fontFamily = Sumi.Mono,
            modifier = Modifier.clickable(onClick = onSkip).padding(vertical = 8.dp),
        )
    }
}

@Composable
private fun SetupButton(label: String, onClick: () -> Unit) {
    Box(
        Modifier.border(Sumi.HairlineWidth, Sumi.Muted).clickable(onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center,
    ) { Text(label, fontSize = 13.sp, color = Sumi.Paper, fontFamily = Sumi.Mono) }
}
