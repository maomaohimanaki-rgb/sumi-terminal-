package dev.sumi.terminal.terminal

/**
 * Emulador VT100/xterm-256color com scrollback (>= 10.000 linhas), tela alternativa (vim, fzf, TUIs),
 * regiões de rolagem, SGR 16/256/truecolor e respostas a DSR/DA.
 * Todas as operações públicas são sincronizadas em [lock].
 */
class TerminalBuffer(
    rows: Int,
    cols: Int,
    private val maxScrollback: Int = 10_000,
    private val respond: (ByteArray) -> Unit,
) {
    class Line(cols: Int) {
        var chars = CharArray(cols) { ' ' }
        var fg = IntArray(cols)   // 0 = padrão, senão 0xFFRRGGBB
        var bg = IntArray(cols)
        var attr = IntArray(cols) // ATTR_*

        fun clear(from: Int, to: Int, bg0: Int = 0) {
            for (i in from until minOf(to, chars.size)) { chars[i] = ' '; fg[i] = 0; bg[i] = bg0; attr[i] = 0 }
        }
        fun resized(cols: Int): Line {
            val n = Line(cols); val m = minOf(cols, chars.size)
            System.arraycopy(chars, 0, n.chars, 0, m); System.arraycopy(fg, 0, n.fg, 0, m)
            System.arraycopy(bg, 0, n.bg, 0, m); System.arraycopy(attr, 0, n.attr, 0, m)
            return n
        }
    }

    data class Selection(val anchorRow: Int, val anchorCol: Int, val headRow: Int, val headCol: Int, val block: Boolean)

    val lock = Any()
    var rows = rows; private set
    var cols = cols; private set
    var curRow = 0; private set
    var curCol = 0; private set
    var altActive = false; private set
    var appCursorKeys = false; private set
    var bracketedPaste = false; private set
    var cursorVisible = true; private set

    private val scrollback = ArrayDeque<Line>()
    // Limite por linhas e por caracteres: uma janela larga não pode multiplicar o uso de RAM.
    private val maxScrollbackChars = 1_000_000
    private var main = Array(rows) { Line(cols) }
    private var alt = Array(rows) { Line(cols) }
    private val screen get() = if (altActive) alt else main

    private var scrollTop = 0
    private var scrollBottom = rows - 1
    private var curFg = 0; private var curBg = 0; private var curAttr = 0
    private var savedRow = 0; private var savedCol = 0
    private var wrapPending = false

    val totalLines: Int get() = synchronized(lock) { if (altActive) rows else scrollback.size + rows }

    fun lineAt(abs: Int): Line = synchronized(lock) {
        if (altActive) alt[abs.coerceIn(0, rows - 1)]
        else if (abs < scrollback.size) scrollback[abs.coerceAtLeast(0)]
        else main[(abs - scrollback.size).coerceIn(0, rows - 1)]
    }

    fun cursorAbsRow(): Int = synchronized(lock) { (if (altActive) 0 else scrollback.size) + curRow }

    // ---------- Parser ----------
    private enum class St { GROUND, ESC, CSI, OSC, CHARSET }
    private var st = St.GROUND
    private val csi = StringBuilder()
    private var oscEsc = false
    private var utf8Need = 0
    private var utf8Cp = 0

    fun feed(data: ByteArray) = synchronized(lock) {
        for (b in data) process(b.toInt() and 0xFF)
    }

    private fun process(b: Int) {
        // Decodificador UTF-8 incremental
        if (st == St.GROUND && b >= 0x80) {
            when {
                b and 0xE0 == 0xC0 -> { utf8Need = 1; utf8Cp = b and 0x1F }
                b and 0xF0 == 0xE0 -> { utf8Need = 2; utf8Cp = b and 0x0F }
                b and 0xF8 == 0xF0 -> { utf8Need = 3; utf8Cp = b and 0x07 }
                b and 0xC0 == 0x80 && utf8Need > 0 -> {
                    utf8Cp = (utf8Cp shl 6) or (b and 0x3F)
                    if (--utf8Need == 0) putCodepoint(utf8Cp)
                }
                else -> utf8Need = 0
            }
            return
        }
        utf8Need = 0
        when (st) {
            St.GROUND -> ground(b)
            St.ESC -> esc(b)
            St.CSI -> {
                if (b in 0x40..0x7E) { st = St.GROUND; csiDispatch(b.toChar(), csi.toString()); csi.setLength(0) }
                else if (b == 0x1B) { st = St.ESC; csi.setLength(0) }
                else csi.append(b.toChar())
            }
            St.OSC -> {
                if (b == 7 || (oscEsc && b == '\\'.code)) { st = St.GROUND; oscEsc = false }
                else oscEsc = b == 0x1B
            }
            St.CHARSET -> st = St.GROUND
        }
    }

    private fun ground(b: Int) {
        when (b) {
            0x07 -> {}
            0x08 -> { if (curCol > 0) curCol--; wrapPending = false }
            0x09 -> { curCol = minOf(((curCol / 8) + 1) * 8, cols - 1); wrapPending = false }
            0x0A, 0x0B, 0x0C -> lineFeed()
            0x0D -> { curCol = 0; wrapPending = false }
            0x1B -> st = St.ESC
            in 0x20..0x7E -> putCodepoint(b)
        }
    }

    private fun esc(b: Int) {
        st = St.GROUND
        when (b.toChar()) {
            '[' -> { st = St.CSI; csi.setLength(0) }
            ']' -> { st = St.OSC; oscEsc = false }
            '(', ')', '*', '+' -> st = St.CHARSET
            '7' -> { savedRow = curRow; savedCol = curCol }
            '8' -> { curRow = savedRow; curCol = savedCol }
            'M' -> reverseIndex()
            'D' -> lineFeed()
            'E' -> { curCol = 0; lineFeed() }
            'c' -> fullReset()
            else -> {}
        }
    }

    private fun putCodepoint(cp: Int) {
        val ch = if (cp <= 0xFFFF) cp.toChar() else '\u25A1'
        if (wrapPending) { curCol = 0; lineFeed(); wrapPending = false }
        val l = screen[curRow]
        l.chars[curCol] = ch; l.fg[curCol] = curFg; l.bg[curCol] = curBg; l.attr[curCol] = curAttr
        if (curCol == cols - 1) wrapPending = true else curCol++
    }

    private fun lineFeed() {
        if (curRow == scrollBottom) scrollUp(1) else if (curRow < rows - 1) curRow++
    }

    private fun reverseIndex() {
        if (curRow == scrollTop) scrollDown(1) else if (curRow > 0) curRow--
    }

    private fun scrollUp(n: Int) {
        val s = screen
        repeat(n) {
            val gone = s[scrollTop]
            if (!altActive && scrollTop == 0) {
                scrollback.addLast(gone)
                trimScrollback()
            }
            for (i in scrollTop until scrollBottom) s[i] = s[i + 1]
            s[scrollBottom] = Line(cols).also { it.clear(0, cols, curBg) }
        }
    }

    private fun trimScrollback() {
        while (scrollback.size > maxScrollback || scrollback.size.toLong() * cols > maxScrollbackChars) {
            if (scrollback.isEmpty()) break
            scrollback.removeFirst()
        }
    }

    private fun scrollDown(n: Int) {
        val s = screen
        repeat(n) {
            for (i in scrollBottom downTo scrollTop + 1) s[i] = s[i - 1]
            s[scrollTop] = Line(cols).also { it.clear(0, cols, curBg) }
        }
    }

    private fun fullReset() {
        scrollTop = 0; scrollBottom = rows - 1; curRow = 0; curCol = 0
        curFg = 0; curBg = 0; curAttr = 0; altActive = false; appCursorKeys = false
        bracketedPaste = false; cursorVisible = true
        for (l in main) l.clear(0, cols)
    }

    private fun csiDispatch(cmd: Char, raw: String) {
        val priv = raw.startsWith("?")
        val p = raw.trimStart('?', '>', '!').split(';').map { it.toIntOrNull() }
        fun a(i: Int, d: Int) = p.getOrNull(i)?.takeIf { it != 0 } ?: d
        wrapPending = false
        when (cmd) {
            'A' -> curRow = maxOf(scrollTop.coerceAtMost(curRow), curRow - a(0, 1))
            'B' -> curRow = minOf(rows - 1, curRow + a(0, 1))
            'C' -> curCol = minOf(cols - 1, curCol + a(0, 1))
            'D' -> curCol = maxOf(0, curCol - a(0, 1))
            'E' -> { curRow = minOf(rows - 1, curRow + a(0, 1)); curCol = 0 }
            'F' -> { curRow = maxOf(0, curRow - a(0, 1)); curCol = 0 }
            'G' -> curCol = (a(0, 1) - 1).coerceIn(0, cols - 1)
            'H', 'f' -> { curRow = (a(0, 1) - 1).coerceIn(0, rows - 1); curCol = (a(1, 1) - 1).coerceIn(0, cols - 1) }
            'd' -> curRow = (a(0, 1) - 1).coerceIn(0, rows - 1)
            'J' -> when (p.getOrNull(0) ?: 0) {
                0 -> { screen[curRow].clear(curCol, cols, curBg); for (r in curRow + 1 until rows) screen[r].clear(0, cols, curBg) }
                1 -> { for (r in 0 until curRow) screen[r].clear(0, cols, curBg); screen[curRow].clear(0, curCol + 1, curBg) }
                2 -> for (r in 0 until rows) screen[r].clear(0, cols, curBg)
                3 -> scrollback.clear()
            }
            'K' -> when (p.getOrNull(0) ?: 0) {
                0 -> screen[curRow].clear(curCol, cols, curBg)
                1 -> screen[curRow].clear(0, curCol + 1, curBg)
                2 -> screen[curRow].clear(0, cols, curBg)
            }
            'L' -> if (curRow in scrollTop..scrollBottom) { val sv = scrollTop; scrollTop = curRow; scrollDown(a(0, 1)); scrollTop = sv }
            'M' -> if (curRow in scrollTop..scrollBottom) { val sv = scrollTop; scrollTop = curRow; scrollUpNoHistory(a(0, 1)); scrollTop = sv }
            'P' -> { val l = screen[curRow]; val n = minOf(a(0, 1), cols - curCol); shiftLeft(l, n) }
            '@' -> { val l = screen[curRow]; val n = minOf(a(0, 1), cols - curCol); shiftRight(l, n) }
            'X' -> screen[curRow].clear(curCol, curCol + a(0, 1), curBg)
            'S' -> scrollUp(a(0, 1))
            'T' -> scrollDown(a(0, 1))
            'r' -> { scrollTop = (a(0, 1) - 1).coerceIn(0, rows - 1); scrollBottom = (a(1, rows) - 1).coerceIn(scrollTop, rows - 1); curRow = 0; curCol = 0 }
            's' -> { savedRow = curRow; savedCol = curCol }
            'u' -> { curRow = savedRow; curCol = savedCol }
            'm' -> sgr(p)
            'n' -> if (p.getOrNull(0) == 6) respond("\u001B[${curRow + 1};${curCol + 1}R".toByteArray())
            'c' -> respond("\u001B[?1;2c".toByteArray())
            'h', 'l' -> if (priv) for (m in p) setMode(m ?: continue, cmd == 'h')
        }
    }

    private fun scrollUpNoHistory(n: Int) {
        val s = screen
        repeat(n) {
            for (i in scrollTop until scrollBottom) s[i] = s[i + 1]
            s[scrollBottom] = Line(cols).also { it.clear(0, cols, curBg) }
        }
    }

    private fun shiftLeft(l: Line, n: Int) {
        for (i in curCol until cols - n) { l.chars[i] = l.chars[i + n]; l.fg[i] = l.fg[i + n]; l.bg[i] = l.bg[i + n]; l.attr[i] = l.attr[i + n] }
        l.clear(cols - n, cols, curBg)
    }

    private fun shiftRight(l: Line, n: Int) {
        for (i in cols - 1 downTo curCol + n) { l.chars[i] = l.chars[i - n]; l.fg[i] = l.fg[i - n]; l.bg[i] = l.bg[i - n]; l.attr[i] = l.attr[i - n] }
        l.clear(curCol, curCol + n, curBg)
    }

    private fun setMode(m: Int, on: Boolean) {
        when (m) {
            1 -> appCursorKeys = on
            25 -> cursorVisible = on
            2004 -> bracketedPaste = on
            47, 1047, 1049 -> {
                if (on && !altActive) { savedRow = curRow; savedCol = curCol; altActive = true; for (l in alt) l.clear(0, cols) }
                else if (!on && altActive) { altActive = false; curRow = savedRow; curCol = savedCol }
                scrollTop = 0; scrollBottom = rows - 1
            }
        }
    }

    private fun sgr(p: List<Int?>) {
        val q = if (p.isEmpty()) listOf(0) else p.map { it ?: 0 }
        var i = 0
        while (i < q.size) {
            when (val c = q[i]) {
                0 -> { curFg = 0; curBg = 0; curAttr = 0 }
                1 -> curAttr = curAttr or ATTR_BOLD
                2 -> curAttr = curAttr or ATTR_DIM
                4 -> curAttr = curAttr or ATTR_UNDERLINE
                7 -> curAttr = curAttr or ATTR_INVERSE
                22 -> curAttr = curAttr and (ATTR_BOLD or ATTR_DIM).inv()
                24 -> curAttr = curAttr and ATTR_UNDERLINE.inv()
                27 -> curAttr = curAttr and ATTR_INVERSE.inv()
                in 30..37 -> curFg = palette(c - 30)
                39 -> curFg = 0
                in 40..47 -> curBg = palette(c - 40)
                49 -> curBg = 0
                in 90..97 -> curFg = palette(c - 90 + 8)
                in 100..107 -> curBg = palette(c - 100 + 8)
                38, 48 -> {
                    val color = when (q.getOrNull(i + 1)) {
                        5 -> palette(q.getOrElse(i + 2) { 0 }).also { i += 2 }
                        2 -> (0xFF000000.toInt() or (q.getOrElse(i + 2) { 0 } shl 16) or (q.getOrElse(i + 3) { 0 } shl 8) or q.getOrElse(i + 4) { 0 }).also { i += 4 }
                        else -> 0
                    }
                    if (c == 38) curFg = color else curBg = color
                }
            }
            i++
        }
    }

    // ---------- Redimensionamento ----------
    fun resize(newRows: Int, newCols: Int) = synchronized(lock) {
        if (newRows == rows && newCols == cols) return
        fun isBlank(l: Line) = l.chars.all { it == ' ' }
        // Tela principal: ao encolher, descarta primeiro linhas vazias abaixo do cursor e só então
        // empurra o topo para o scrollback; ao crescer, puxa o scrollback de volta. O conteúdo
        // nunca se perde quando o teclado abre/fecha.
        val ml = main.map { it.resized(newCols) }.toMutableList()
        var mainCur = if (altActive) savedRow else curRow
        while (ml.size > newRows && ml.size - 1 > mainCur && isBlank(ml.last())) ml.removeAt(ml.size - 1)
        while (ml.size > newRows) { scrollback.addLast(ml.removeAt(0)); mainCur = maxOf(0, mainCur - 1) }
        while (ml.size < newRows) {
            if (scrollback.isNotEmpty()) { ml.add(0, scrollback.removeLast()); mainCur++ } else ml.add(Line(newCols))
        }
        main = ml.toTypedArray()
        if (altActive) savedRow = mainCur.coerceIn(0, newRows - 1) else curRow = mainCur
        alt = Array(newRows) { i -> alt.getOrNull(i)?.resized(newCols) ?: Line(newCols) }
        for (i in scrollback.indices) scrollback[i] = scrollback[i].resized(newCols)
        rows = newRows; cols = newCols
        trimScrollback()
        scrollTop = 0; scrollBottom = rows - 1
        curRow = curRow.coerceIn(0, rows - 1); curCol = curCol.coerceIn(0, cols - 1)
    }

    // ---------- Seleção ----------
    private fun bounds(s: Selection): List<IntArray> {
        val aFirst = s.anchorRow < s.headRow || (s.anchorRow == s.headRow && s.anchorCol <= s.headCol)
        val (r1, c1, r2, c2) = if (aFirst) listOf(s.anchorRow, s.anchorCol, s.headRow, s.headCol)
        else listOf(s.headRow, s.headCol, s.anchorRow, s.anchorCol)
        return (r1..r2).map { r ->
            val (from, to) = when {
                s.block -> minOf(s.anchorCol, s.headCol) to maxOf(s.anchorCol, s.headCol)
                r == r1 && r == r2 -> c1 to c2
                r == r1 -> c1 to cols - 1
                r == r2 -> 0 to c2
                else -> 0 to cols - 1
            }
            intArrayOf(r, from, to)
        }
    }

    fun selectionSpans(s: Selection): List<IntArray> = synchronized(lock) { bounds(s) }

    fun extract(s: Selection): String = synchronized(lock) {
        bounds(s).joinToString("\n") { (r, f, t) ->
            val l = lineAt(r); String(l.chars, f.coerceIn(0, cols - 1), (t - f + 1).coerceIn(0, cols - f)).trimEnd()
        }.trimEnd('\n')
    }

    /** Última linha (absoluta) com algum texto; usada por "selecionar tudo". */
    fun lastContentRow(): Int = synchronized(lock) {
        for (r in totalLines - 1 downTo 0) {
            if (lineAt(r).chars.any { it != ' ' && it.code != 0 }) return@synchronized r
        }
        0
    }

    /** Colunas [início, fim] da "palavra" (sequência sem espaços) sob [col]. */
    fun wordBounds(row: Int, col: Int): Pair<Int, Int> = synchronized(lock) {
        val chars = lineAt(row).chars
        val c = col.coerceIn(0, cols - 1)
        fun blank(i: Int) = chars[i] == ' ' || chars[i].code == 0
        if (blank(c)) return@synchronized c to c
        var a = c; var b = c
        while (a > 0 && !blank(a - 1)) a--
        while (b < cols - 1 && !blank(b + 1)) b++
        a to b
    }

    fun clearSelection(s: Selection) = synchronized(lock) {
        for ((r, f, t) in bounds(s)) lineAt(r).clear(f, t + 1)
    }

    companion object {
        const val ATTR_BOLD = 1; const val ATTR_UNDERLINE = 2; const val ATTR_INVERSE = 4; const val ATTR_DIM = 8

        private val ansi16 = intArrayOf(
            0x4A4A4A, 0xD9383A, 0x7A9A6B, 0xC9A66B, 0x4A6FA5, 0x9B6B9E, 0x5F9EA0, 0xE6E6E6,
            0x4A4A4A, 0xF0605F, 0x9BBF8A, 0xE6C98A, 0x6F95C9, 0xC08FC4, 0x84C3C5, 0xFAFAFA,
        )

        fun palette(i: Int): Int {
            val n = i.coerceIn(0, 255)
            val rgb = when {
                n < 16 -> ansi16[n]
                n < 232 -> { val k = n - 16; fun lv(x: Int) = if (x == 0) 0 else 55 + x * 40
                    (lv(k / 36) shl 16) or (lv((k / 6) % 6) shl 8) or lv(k % 6) }
                else -> { val g = 8 + (n - 232) * 10; (g shl 16) or (g shl 8) or g }
            }
            return 0xFF000000.toInt() or rgb
        }
    }
}
