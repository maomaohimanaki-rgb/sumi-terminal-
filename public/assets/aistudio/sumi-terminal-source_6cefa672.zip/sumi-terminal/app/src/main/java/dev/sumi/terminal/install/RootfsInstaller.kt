package dev.sumi.terminal.install

import android.content.Context
import android.system.Os
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.compressors.gzip.GzipCompressorInputStream
import org.apache.commons.compress.utils.CountingInputStream
import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

enum class InstallPhase(val label: String) {
    Checking("Verificando espaço e rede"),
    Downloading("Baixando Arch Linux ARM64"),
    Extracting("Descompactando o sistema"),
    Configuring("Ajustando permissões e rede"),
}

sealed interface InstallState {
    data object Idle : InstallState
    data class Working(val phase: InstallPhase, val progress: Float?, val detail: String) : InstallState
    data object Done : InstallState
    data class Failed(val message: String) : InstallState
}

/**
 * Instalador de primeiro boot. Roda num escopo próprio (não morre com a Activity) e é retomável:
 * o download usa Range sobre o arquivo .part, e a extração só vale se o marcador final existir.
 */
@Singleton
class RootfsInstaller @Inject constructor(@ApplicationContext private val ctx: Context) {

    companion object {
        // O certificado de os.archlinuxarm.org não cobre esse hostname; este mirror tem TLS válido.
        const val ROOTFS_URL = "https://fl.us.mirror.archlinuxarm.org/os/ArchLinuxARM-aarch64-latest.tar.gz"
        private const val MARKER = ".sumi-installed"
        private const val MIN_FREE_BYTES = 3L * 1024 * 1024 * 1024
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()

    private val _state = MutableStateFlow<InstallState>(InstallState.Idle)
    val state: StateFlow<InstallState> = _state.asStateFlow()
    private var job: Job? = null

    val rootfs: File get() = File(ctx.filesDir, "usr")
    private val archive: File get() = File(ctx.filesDir, "downloads/rootfs.tar.gz")

    fun isInstalled(): Boolean = File(rootfs, MARKER).exists() && File(rootfs, "usr/bin/bash").exists()

    fun start() {
        if (isInstalled()) { _state.value = InstallState.Done; return }
        if (job?.isActive == true) return
        job = scope.launch {
            try {
                install()
                _state.value = InstallState.Done
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                _state.value = InstallState.Failed(e.message ?: e::class.java.simpleName)
            }
        }
    }

    private suspend fun install() {
        work(InstallPhase.Checking, null, "")
        archive.parentFile?.mkdirs()
        if (ctx.filesDir.usableSpace < MIN_FREE_BYTES && !archive.exists()) {
            throw IOException("Espaço insuficiente: são necessários cerca de 3 GB livres.")
        }
        if (!archive.exists()) download()
        extract()
        work(InstallPhase.Configuring, null, "")
        configure()
        archive.delete()
    }

    private fun work(phase: InstallPhase, progress: Float?, detail: String) {
        _state.value = InstallState.Working(phase, progress, detail)
    }

    private suspend fun download() {
        val part = File(archive.path + ".part")
        var attempt = 0
        while (true) {
            try { downloadOnce(part); break }
            catch (e: IOException) {
                if (++attempt >= 5) throw IOException("Falha no download: ${e.message}")
                delay(2000L * attempt)
            }
        }
        if (!part.renameTo(archive)) throw IOException("Não foi possível finalizar o arquivo baixado")
    }

    private suspend fun downloadOnce(part: File) {
        val have = if (part.exists()) part.length() else 0L
        val req = Request.Builder().url(ROOTFS_URL)
            .apply { if (have > 0) header("Range", "bytes=$have-") }.build()
        client.newCall(req).execute().use { resp ->
            if (resp.code == 416) return // .part já está completo
            if (!resp.isSuccessful) throw IOException("HTTP ${resp.code}")
            val body = resp.body ?: throw IOException("Resposta sem corpo")
            val resumed = resp.code == 206
            var done = if (resumed) have else 0L
            val len = body.contentLength()
            val total = if (len > 0) done + len else -1L
            val buf = ByteArray(128 * 1024)
            var lastPublish = 0L
            FileOutputStream(part, resumed).use { out ->
                body.byteStream().use { input ->
                    while (true) {
                        currentCoroutineContext().ensureActive()
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        done += n
                        val now = System.currentTimeMillis()
                        if (now - lastPublish > 250) {
                            lastPublish = now
                            work(
                                InstallPhase.Downloading,
                                if (total > 0) done.toFloat() / total else null,
                                if (total > 0) "${mb(done)} / ${mb(total)} MB" else "${mb(done)} MB",
                            )
                        }
                    }
                }
            }
        }
    }

    private suspend fun extract() {
        val root = rootfs
        root.deleteRecursively()
        root.mkdirs()
        val totalBytes = archive.length().toFloat().coerceAtLeast(1f)
        val counting = CountingInputStream(BufferedInputStream(FileInputStream(archive), 256 * 1024))
        var lastPublish = 0L
        var files = 0
        TarArchiveInputStream(GzipCompressorInputStream(counting), "UTF-8").use { tar ->
            while (true) {
                currentCoroutineContext().ensureActive()
                val e = tar.nextEntry ?: break
                val name = e.name.removePrefix("./").trimEnd('/')
                if (name.isEmpty() || name.split('/').any { it == ".." }) continue
                val target = File(root, name)
                val mode = e.mode and 0x1FF
                when {
                    e.isDirectory -> { target.mkdirs(); chmod(target, mode or 0x1C0) } // 0700: dono sempre escreve
                    e.isSymbolicLink -> {
                        target.parentFile?.mkdirs()
                        target.delete()
                        Os.symlink(e.linkName, target.path)
                    }
                    e.isLink -> {
                        val src = File(root, e.linkName.removePrefix("./"))
                        target.parentFile?.mkdirs()
                        if (src.exists()) { src.copyTo(target, overwrite = true); chmod(target, mode or 0x180) }
                    }
                    e.isFile -> {
                        target.parentFile?.mkdirs()
                        FileOutputStream(target).use { out -> tar.copyTo(out, 64 * 1024) }
                        chmod(target, mode or 0x180) // 0600: dono sempre lê/escreve
                        files++
                    }
                    else -> Unit // dispositivos/fifos: o proot faz bind de /dev
                }
                val now = System.currentTimeMillis()
                if (now - lastPublish > 250) {
                    lastPublish = now
                    work(InstallPhase.Extracting, counting.bytesRead / totalBytes, "$files arquivos")
                }
            }
        }
    }

    private fun configure() {
        val root = rootfs
        fun write(path: String, text: String) {
            val f = File(root, path)
            f.parentFile?.mkdirs()
            f.delete()
            f.writeText(text)
        }
        write("etc/resolv.conf", "nameserver 1.1.1.1\nnameserver 8.8.8.8\n")
        write("etc/hosts", "127.0.0.1 localhost\n::1 localhost\n")
        write("etc/locale.conf", "LANG=C.UTF-8\nLC_ALL=C.UTF-8\n")
        File(root, "root").mkdirs()
        File(root, "tmp").apply { mkdirs(); chmod(this, 0x3FF) } // 1777

        // Sem landlock/CheckSpace dentro do proot, o pacman falha antes de baixar qualquer pacote.
        File(root, "etc/pacman.conf").takeIf { it.isFile }?.let { conf ->
            val out = StringBuilder()
            conf.readLines().forEach { line ->
                when {
                    line.trim() == "CheckSpace" -> out.append("#CheckSpace\n")
                    line.trim() == "[options]" -> out.append("[options]\nDisableSandbox\n")
                    else -> out.append(line).append('\n')
                }
            }
            conf.writeText(out.toString())
        }

        val profile = File(root, "root/.bash_profile")
        if (!profile.exists()) profile.writeText(
            """
            [ -f ~/.bashrc ] && . ~/.bashrc
            if [ ! -f /etc/pacman.d/gnupg/trustdb.gpg ]; then
              echo "[sumi] Inicializando chaves do pacman (só na primeira vez)..."
              pacman-key --init && pacman-key --populate archlinuxarm
            fi
            """.trimIndent() + "\n",
        )

        listOf("usr/bin/bash", "usr/bin/env", "usr/bin/sh", "usr/bin/pacman", "usr/bin/ls").forEach { rel ->
            File(root, rel).takeIf { it.isFile }?.let { chmod(it, 0x1ED) } // 0755
        }
        File(root, MARKER).writeText("archlinuxarm-aarch64\n")
    }

    private fun chmod(f: File, mode: Int) {
        try { Os.chmod(f.path, mode) } catch (_: Exception) { }
    }

    private fun mb(bytes: Long) = bytes / (1024 * 1024)
}
