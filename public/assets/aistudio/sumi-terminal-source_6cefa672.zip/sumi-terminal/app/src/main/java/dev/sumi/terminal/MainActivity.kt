package dev.sumi.terminal

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.isImeVisible
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Text
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import dagger.hilt.android.AndroidEntryPoint
import dev.sumi.terminal.service.TerminalDaemonService
import dev.sumi.terminal.service.TerminalSessionManager
import dev.sumi.terminal.install.RootfsInstaller
import dev.sumi.terminal.ui.FileManagerScreen
import dev.sumi.terminal.ui.SetupScreen
import dev.sumi.terminal.ui.Sumi
import dev.sumi.terminal.ui.SumiTheme
import dev.sumi.terminal.ui.TerminalScreen
import javax.inject.Inject

@OptIn(ExperimentalLayoutApi::class)
@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    @Inject lateinit var sessions: TerminalSessionManager
    @Inject lateinit var installer: RootfsInstaller

    private val notifPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) {}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Edge-to-edge: necessário para que imePadding()/WindowInsets.ime reportem o teclado.
        WindowCompat.setDecorFitsSystemWindows(window, false)

        if (Build.VERSION.SDK_INT >= 33) notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        TerminalDaemonService.start(this)
        requestIgnoreBatteryOptimizations()

        setContent {
            SumiTheme {
                var tab by rememberSaveable { mutableIntStateOf(0) }
                var skipSetup by rememberSaveable { mutableStateOf(false) }
                val installState by installer.state.collectAsState()
                val ready = skipSetup || remember(installState) { installer.isInstalled() }
                LaunchedEffect(Unit) { installer.start() }

                if (!ready) {
                    SetupScreen(installState, onRetry = installer::start, onSkip = { skipSetup = true })
                    return@SumiTheme
                }

                val imeVisible = WindowInsets.isImeVisible
                Column(Modifier.fillMaxSize().background(Sumi.Sumi1).statusBarsPadding().imePadding()) {
                    Box(Modifier.weight(1f)) {
                        Crossfade(tab, label = "workspace") { t ->
                            if (t == 0) TerminalScreen(onKeepScreenOn = ::setKeepScreenOn, onOpenFiles = { tab = 1 })
                            else FileManagerScreen(rootfs = sessions.rootfs)
                        }
                    }
                    // A barra de navegação some com o IME aberto para não competir com a AccessoryBar.
                    if (!imeVisible) Column(Modifier.background(Sumi.Sumi2).navigationBarsPadding()) {
                        Row(Modifier.fillMaxWidth().height(40.dp), verticalAlignment = Alignment.CenterVertically) {
                            NavTab("\u7AEF\u672B  terminal", tab == 0, Modifier.weight(1f)) { tab = 0 }
                            NavTab("\u30D5\u30A1\u30A4\u30EB  arquivos", tab == 1, Modifier.weight(1f)) { tab = 1 }
                        }
                    }
                }
            }
        }
    }

    private fun setKeepScreenOn(on: Boolean) {
        if (on) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    private fun requestIgnoreBatteryOptimizations() {
        val pm = getSystemService(PowerManager::class.java)
        if (!pm.isIgnoringBatteryOptimizations(packageName)) {
            startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
            )
        }
    }
}

@androidx.compose.runtime.Composable
private fun NavTab(label: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Box(modifier.fillMaxSize().clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Text(label, fontSize = 12.sp, fontFamily = Sumi.Mono,
            color = if (selected) Sumi.Paper else Sumi.Muted)
    }
}
