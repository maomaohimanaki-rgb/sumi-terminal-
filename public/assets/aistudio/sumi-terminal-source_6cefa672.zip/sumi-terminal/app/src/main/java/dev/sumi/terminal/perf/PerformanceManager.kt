package dev.sumi.terminal.perf

import android.content.Context
import android.os.Build
import android.os.PerformanceHintManager
import android.os.PowerManager
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.Executors
import javax.inject.Inject
import javax.inject.Singleton

/**
 * ADPF: PerformanceHintSession (API 31+, degradação silenciosa na API 30) e
 * OnThermalStatusChangedListener (API 29+) que reduz o framerate do terminal sob calor.
 *
 * Limitação do Android: os tids de uma hint session precisam pertencer ao PRÓPRIO processo.
 * Por isso vinculamos a thread nativa "pty-reader" e a thread do emulador; o bash/clang rodam
 * em outro processo (filho do forkpty) e herdam prioridade pelo cgroup do app em foreground service.
 */
@Singleton
class PerformanceManager @Inject constructor(@ApplicationContext private val ctx: Context) {

    private val power = ctx.getSystemService(PowerManager::class.java)
    private val executor = Executors.newSingleThreadExecutor()

    private val _thermal = MutableStateFlow(PowerManager.THERMAL_STATUS_NONE)
    val thermalStatus: StateFlow<Int> = _thermal.asStateFlow()

    /** Intervalo mínimo entre quadros de renderização, adaptado ao estado térmico. */
    private val _frameIntervalMs = MutableStateFlow(16L)
    val frameIntervalMs: StateFlow<Long> = _frameIntervalMs.asStateFlow()

    private val tids = LinkedHashSet<Int>()
    private var session: PerformanceHintManager.Session? = null
    private var targetNs = FRAME_TARGET_NS
    private var started = false

    private val listener = PowerManager.OnThermalStatusChangedListener { applyThermal(it) }

    @Synchronized
    fun start() {
        if (started) return
        started = true
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            power.addThermalStatusListener(executor, listener)
            applyThermal(power.currentThermalStatus)
        }
    }

    @Synchronized
    fun stop() {
        if (!started) return
        started = false
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) power.removeThermalStatusListener(listener)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) session?.close()
        session = null
    }

    /** Registra uma thread crítica; a sessão é recriada com o conjunto atualizado de tids. */
    @Synchronized
    fun attachThread(tid: Int) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S || tid <= 0) return
        if (!tids.add(tid)) return
        session?.close()
        val mgr = ctx.getSystemService(PerformanceHintManager::class.java) ?: return
        session = mgr.createHintSession(tids.toIntArray(), targetNs)
    }

    /** Reporta a duração real do trabalho (processar um chunk de saída) para o escalonador. */
    fun reportWork(durationNs: Long) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            try { session?.reportActualWorkDuration(durationNs.coerceAtLeast(1)) } catch (_: IllegalStateException) {}
        }
    }

    private fun applyThermal(status: Int) {
        _thermal.value = status
        _frameIntervalMs.value = when {
            status >= PowerManager.THERMAL_STATUS_CRITICAL -> 250L
            status >= PowerManager.THERMAL_STATUS_SEVERE -> 100L
            status >= PowerManager.THERMAL_STATUS_MODERATE -> 50L
            status >= PowerManager.THERMAL_STATUS_LIGHT -> 33L
            else -> 16L
        }
        // Sob calor, relaxa o alvo para o governor não escalar clocks desnecessariamente.
        targetNs = if (status >= PowerManager.THERMAL_STATUS_MODERATE) FRAME_TARGET_NS * 4 else FRAME_TARGET_NS
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            try { session?.updateTargetWorkDuration(targetNs) } catch (_: IllegalStateException) {}
        }
    }

    companion object { private const val FRAME_TARGET_NS = 8_000_000L }
}
