package dev.sumi.terminal.ui

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import dev.sumi.terminal.R
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

object TerminalAppearance {
    var background by mutableStateOf(Color(0xFF121212))
    var foreground by mutableStateOf(Color(0xFFE6E6E6))
    var accent by mutableStateOf(Color(0xFFE6C98A))
    var brightness by mutableStateOf(1f)
    var backgroundImage by mutableStateOf<ImageBitmap?>(null)
    var autoCommandColors by mutableStateOf(false)

    fun setPalette(bg: Color, fg: Color, mark: Color) {
        background = bg
        foreground = fg
        accent = mark
    }

    fun scaledBackground(): Color = Color(
        (background.red * brightness).coerceIn(0f, 1f),
        (background.green * brightness).coerceIn(0f, 1f),
        (background.blue * brightness).coerceIn(0f, 1f),
        1f,
    )
}

object Sumi {
    val Sumi1 = Color(0xFF121212)
    val Sumi2 = Color(0xFF1A1A1A)
    val Hairline = Color(0xFF2C2C2C)
    val Shironeri = Color(0xFFE6E6E6)
    val Paper = Color(0xFFFAFAFA)
    val Muted = Color(0xFF8A8A8A)
    val Kurenai = Color(0xFFD9383A)  // erro
    val Aizome = Color(0xFF204051)   // sucesso / seleção
    val HairlineWidth = 0.5.dp

    val Kinari = Color(0xFFE6C98A)   // fundo da seleção: alto contraste sobre o carvão

    val Mono: FontFamily = FontFamily(
        Font(R.font.jetbrains_mono_regular, FontWeight.Normal),
        Font(R.font.jetbrains_mono_bold, FontWeight.Bold),
    )
    val Sans: FontFamily = FontFamily.SansSerif // substitua por Noto Sans JP / Inter via res/font

    fun <T> softSpring() = spring<T>(dampingRatio = Spring.DampingRatioLowBouncy, stiffness = Spring.StiffnessMediumLow)
}

@Composable
fun SumiTheme(content: @Composable () -> Unit) {
    @Suppress("UNUSED_VARIABLE") val dark = isSystemInDarkTheme() // tema é sempre carvão: wabi-sabi não tem modo claro
    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Sumi.Sumi1, surface = Sumi.Sumi2, onBackground = Sumi.Shironeri,
            onSurface = Sumi.Shironeri, primary = Sumi.Paper, onPrimary = Sumi.Sumi1,
            secondary = Sumi.Aizome, error = Sumi.Kurenai, outline = Sumi.Hairline,
        ),
        typography = Typography(
            labelSmall = TextStyle(fontFamily = Sumi.Sans, fontSize = 11.sp, letterSpacing = 0.6.sp),
            bodyMedium = TextStyle(fontFamily = Sumi.Sans, fontSize = 14.sp),
        ),
        content = content,
    )
}
