package dev.sumi.terminal.service

import android.content.Context
import dagger.hilt.android.qualifiers.ApplicationContext
import dev.sumi.terminal.nativebridge.PtyListener
import dev.sumi.terminal.nativebridge.PtyNative
import dev.sumi.terminal.perf.PerformanceManager
import dev.sumi.terminal.terminal.TerminalBuffer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import java.util.concurrent.Executors
import javax.inject.Inject
import javax.inject.Singleton

data class LaunchConfig(val cmd: String, val args: List<String>, val env: List<String>, val cwd: String) {
    val label get() = (listOf(cmd) + args.drop(1)).joinToString(" ").take(60)
}

class TerminalSession(
    val id: Int,
    val title: String,
    private val config: LaunchConfig,
    private val perf: PerformanceManager,
    private val dispatcher: AgentAlertDispatcher,
) : PtyListener {

    private val writer = Executors.newSingleThreadExecutor { Thread(it, "pty-writer-$id") }
    @Volatile private var handle = 0L

    val buffer = TerminalBuffer(24, 80, respond = { write(it) })
    val frames = MutableStateFlow(0L)
    val alive = MutableStateFlow(false)
    val exitCode = MutableStateFlow<Int?>(null)

    fun start(rows: Int, cols: Int) {
        buffer.resize(rows, cols)
        handle = PtyNative.nativeStart(config.cmd, config.args.toTypedArray(), config.env.toTypedArray(), config.cwd, rows, cols, this)
        alive.value = handle != 0L
        if (handle == 0L) exitCode.value = -1
    }

    fun write(bytes: ByteArray) {
        val h = handle
        if (h == 0L || !alive.value) return
        writer.execute { PtyNative.nativeWrite(h, bytes) }
    }

    fun resize(rows: Int, cols: Int) {
        if (rows == buffer.rows && cols == buffer.cols) return
        buffer.resize(rows, cols)
        if (handle != 0L) PtyNative.nativeResize(handle, rows, cols)
        frames.value++
    }

    fun terminate() { if (handle != 0L) PtyNative.nativeKill(handle, 9) }

    override fun onReaderStarted(tid: Int) = perf.attachThread(tid)

    override fun onOutput(data: ByteArray) {
        val t0 = System.nanoTime()
        buffer.feed(data)
        frames.value++
        perf.reportWork(System.nanoTime() - t0)
    }

    override fun onExit(code: Int) {
        exitCode.value = code
        alive.value = false
        handle = 0L
        buffer.feed("\r\n\u001B[2m[processo finalizado com código $code]\u001B[0m\r\n".toByteArray())
        frames.value++
        dispatcher.emit(AgentEvent.ProcessExit(id, config.label, code))
    }
}

/**
 * Dono de todas as sessões. É @Singleton: o buffer e o processo de cada aba sobrevivem à troca
 * de abas do app, à recomposição e à recriação da Activity.
 */
@Singleton
class TerminalSessionManager @Inject constructor(
    @ApplicationContext private val ctx: Context,
    private val perf: PerformanceManager,
    private val dispatcher: AgentAlertDispatcher,
) {
    private var nextId = 1
    private val _sessions = MutableStateFlow<List<TerminalSession>>(emptyList())
    val sessions: StateFlow<List<TerminalSession>> = _sessions.asStateFlow()
    private val _activeId = MutableStateFlow(0)
    val activeId: StateFlow<Int> = _activeId.asStateFlow()

    val current: TerminalSession? get() = _sessions.value.firstOrNull { it.id == _activeId.value }

    val rootfs: File get() = File(ctx.filesDir, "usr")

    fun rootfsReady(): Boolean = File(rootfs, "usr/bin/bash").exists()

    fun defaultConfig(): LaunchConfig {
        val libDir = ctx.applicationInfo.nativeLibraryDir
        val proot = File(libDir, "libproot.so")
        val tmp = File(ctx.cacheDir, "proot-tmp").apply { mkdirs() }
        return if (proot.exists() && rootfsReady()) {
            // O Arch pode carregar /etc/locale.conf depois do ambiente do proot e
            // reintroduzir en_US.UTF-8. Corrige também instalações já existentes.
            File(rootfs, "etc/locale.conf").apply {
                parentFile?.mkdirs()
                writeText("LANG=C.UTF-8\\nLC_ALL=C.UTF-8\\n")
            }
            val binds = mutableListOf("-b", "/dev", "-b", "/proc", "-b", "/sys")
            if (File("/storage/emulated/0").exists()) binds += listOf("-b", "/storage/emulated/0:/sdcard")
            LaunchConfig(
                cmd = proot.absolutePath,
                args = listOf("proot", "--kill-on-exit", "--link2symlink", "-0", "-r", rootfs.absolutePath) + binds + listOf(
                    "-w", "/root",
                    "/usr/bin/env", "-i", "HOME=/root", "TERM=xterm-256color", "COLORTERM=truecolor",
                    // C.UTF-8 existe mesmo em rootfs mínimos e evita o aviso do setlocale.
                    "LANG=C.UTF-8", "LC_ALL=C.UTF-8",
                    "PS1=\\u@\\h:\\w\\$ ",
                    "PATH=/usr/local/sbin:/usr/local/bin:/usr/bin:/usr/sbin",
                    "/usr/bin/bash", "--login", "-i",
                ),
                env = listOf(
                    "PROOT_TMP_DIR=${tmp.absolutePath}",
                    "PROOT_LOADER=$libDir/libproot-loader.so",
                    "PROOT_LOADER_32=$libDir/libproot-loader32.so",
                ),
                cwd = ctx.filesDir.absolutePath,
            )
        } else LaunchConfig(
            cmd = "/system/bin/sh", args = listOf("sh", "-l"),
            env = listOf("TERM=xterm-256color", "HOME=${ctx.filesDir.absolutePath}", "PATH=/system/bin:/system/xbin"),
            cwd = ctx.filesDir.absolutePath,
        )
    }

    @Synchronized
    fun newSession(rows: Int = 24, cols: Int = 80): TerminalSession {
        val id = nextId++
        val s = TerminalSession(id, "shell $id", defaultConfig(), perf, dispatcher)
        _sessions.value = _sessions.value + s
        _activeId.value = id
        s.start(rows, cols)
        return s
    }

    @Synchronized
    fun select(id: Int) { if (_sessions.value.any { it.id == id }) _activeId.value = id }

    @Synchronized
    fun close(id: Int) {
        val list = _sessions.value
        val idx = list.indexOfFirst { it.id == id }
        if (idx < 0) return
        list[idx].terminate()
        val rest = list.filterNot { it.id == id }
        _sessions.value = rest
        if (_activeId.value == id) _activeId.value = rest.getOrNull(minOf(idx, rest.lastIndex))?.id ?: 0
    }
}
