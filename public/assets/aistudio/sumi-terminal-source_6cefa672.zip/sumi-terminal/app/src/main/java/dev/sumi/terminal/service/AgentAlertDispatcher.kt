package dev.sumi.terminal.service

import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import javax.inject.Inject
import javax.inject.Singleton

sealed interface AgentEvent {
    data class ProcessExit(val sessionId: Int, val command: String, val exitCode: Int) : AgentEvent
    /** Payload recebido no socket local: "ok|mensagem" ou "error|mensagem". */
    data class Hook(val success: Boolean, val message: String) : AgentEvent
}

@Singleton
class AgentAlertDispatcher @Inject constructor() {
    private val _events = MutableSharedFlow<AgentEvent>(extraBufferCapacity = 64, onBufferOverflow = BufferOverflow.DROP_OLDEST)
    val events: SharedFlow<AgentEvent> = _events.asSharedFlow()
    fun emit(event: AgentEvent) { _events.tryEmit(event) }
}
