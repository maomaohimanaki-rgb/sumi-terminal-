package dev.sumi.terminal.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.onClick
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import kotlinx.coroutines.withTimeoutOrNull
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.sumi.terminal.terminal.TermKey

/**
 * Barra acima do IME. Posicione-a DEPOIS do conteúdo em uma Column com `imePadding()`:
 * ela fica colada na borda superior do teclado, sem cobrir a faixa de sugestões (que é parte da
 * janela do IME). Os botões usam `clickable` (não focáveis por toque), então o foco do campo oculto
 * - e o teclado - permanecem ativos.
 */
@Composable
fun AccessoryBar(state: TerminalUiState, onIntent: (TerminalIntent) -> Unit, modifier: Modifier = Modifier) {
    AnimatedContent(targetState = state.selecting, label = "bar", modifier = modifier) { selecting ->
        if (selecting) SelectionBar(state, onIntent) else KeysBar(state, onIntent)
    }
}

@Composable
private fun KeysBar(s: TerminalUiState, i: (TerminalIntent) -> Unit) {
    LazyRow(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(8.dp, spotColor = Color.Black, ambientColor = Color.Black)
            .background(Sumi.Sumi2)
            .border(Sumi.HairlineWidth, Sumi.Hairline),
        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 5.dp),
        horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(4.dp),
    ) {
        item { Key("Ctrl", active = s.ctrl) { i(TerminalIntent.ToggleCtrl) } }
        item { Key("Alt", active = s.alt) { i(TerminalIntent.ToggleAlt) } }
        item { Key("Shift", active = s.shift) { i(TerminalIntent.ToggleShift) } }
        item { Key("Esc") { i(TerminalIntent.Key(TermKey.ESC)) } }
        item { Key("Tab") { i(TerminalIntent.Key(TermKey.TAB)) } }
        item { Key("Enter") { i(TerminalIntent.Key(TermKey.ENTER)) } }
        item { Key("\u2190", repeat = true) { i(TerminalIntent.Key(TermKey.LEFT)) } }
        item { Key("\u2193", repeat = true) { i(TerminalIntent.Key(TermKey.DOWN)) } }
        item { Key("\u2191", repeat = true) { i(TerminalIntent.Key(TermKey.UP)) } }
        item { Key("\u2192", repeat = true) { i(TerminalIntent.Key(TermKey.RIGHT)) } }
        item { Key("Home") { i(TerminalIntent.Key(TermKey.HOME)) } }
        item { Key("End") { i(TerminalIntent.Key(TermKey.END)) } }
        item { Key("PgUp", repeat = true) { i(TerminalIntent.Key(TermKey.PGUP)) } }
        item { Key("PgDn", repeat = true) { i(TerminalIntent.Key(TermKey.PGDN)) } }
        item { Key("Ins") { i(TerminalIntent.Key(TermKey.INS)) } }
        item { Key("Del", repeat = true) { i(TerminalIntent.Key(TermKey.DEL)) } }
        item { Key("Desfazer", enabled = s.canUndo) { i(TerminalIntent.Undo) } }
        item { Key("Refazer", enabled = s.canRedo) { i(TerminalIntent.Redo) } }
        item { Key("Selecionar") { i(TerminalIntent.BeginSelection(null, null)) } }
        item { Key("Tudo") { i(TerminalIntent.SelectAll) } }
        item { Key("Colar") { i(TerminalIntent.RequestPaste) } }
        item { Key("Tela ativa", active = s.keepScreenOn) { i(TerminalIntent.ToggleKeepScreenOn) } }
    }
}

@Composable
private fun SelectionBar(s: TerminalUiState, i: (TerminalIntent) -> Unit) {
    LazyRow(
        modifier = Modifier.fillMaxWidth().background(Sumi.Sumi2).border(Sumi.HairlineWidth, Sumi.Hairline),
        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 5.dp),
        horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(4.dp),
    ) {
        item { Key("Copiar", active = true, enabled = s.selection != null) { i(TerminalIntent.Copy) } }
        item { Key("Tudo") { i(TerminalIntent.SelectAll) } }
        item { Key("Desmarcar") { i(TerminalIntent.ExitSelection) } }
        item { Key("\u2190", repeat = true) { i(TerminalIntent.MoveSelection(0, -1)) } }
        item { Key("\u2193", repeat = true) { i(TerminalIntent.MoveSelection(1, 0)) } }
        item { Key("\u2191", repeat = true) { i(TerminalIntent.MoveSelection(-1, 0)) } }
        item { Key("\u2192", repeat = true) { i(TerminalIntent.MoveSelection(0, 1)) } }
        item { Key("+5 linhas", repeat = true) { i(TerminalIntent.MoveSelection(5, 0)) } }
        item { Key("-5 linhas", repeat = true) { i(TerminalIntent.MoveSelection(-5, 0)) } }
        item { Key(if (s.selection?.block == true) "Bloco" else "Linha") { i(TerminalIntent.ToggleBlock) } }
        item { Key("Cortar") { i(TerminalIntent.Cut) } }
        item { Key("Excluir", danger = true) { i(TerminalIntent.DeleteBlock) } }
    }
}

@Composable
private fun Key(
    label: String,
    active: Boolean = false,
    enabled: Boolean = true,
    danger: Boolean = false,
    repeat: Boolean = false,
    onClick: () -> Unit,
) {
    var pressed by remember { mutableStateOf(false) }
    val currentClick by rememberUpdatedState(onClick)
    val bg by animateColorAsState(
        when {
            danger -> Sumi.Kurenai
            active -> Sumi.Shironeri
            pressed -> Sumi.Hairline
            else -> Sumi.Sumi1
        },
        animationSpec = Sumi.softSpring(), label = "keybg",
    )
    val fg = if (active) Sumi.Sumi1 else Sumi.Shironeri
    val shape = RoundedCornerShape(6.dp)
    Box(
        modifier = Modifier
            .height(36.dp)
            .widthIn(min = 40.dp)
            .alpha(if (enabled) 1f else 0.35f)
            .background(bg, shape)
            .border(Sumi.HairlineWidth, Sumi.Hairline, shape)
            .semantics(mergeDescendants = true) {
                role = Role.Button
                if (enabled) onClick(label) { currentClick(); true }
            }
            .pointerInput(enabled, repeat) {
                if (!enabled) return@pointerInput
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false)
                    pressed = true
                    if (!repeat) {
                        // Soltar dentro da tecla = clique; arrastar (rolar a barra) cancela.
                        if (waitForUpOrCancellation() != null) currentClick()
                    } else {
                        // 1 = soltou, 2 = cancelado (rolagem da barra), null = segurando parado.
                        val outcome = withTimeoutOrNull(HOLD_CONFIRM_MS) { if (waitForUpOrCancellation() != null) 1 else 2 }
                        when (outcome) {
                            1 -> currentClick()
                            2 -> Unit
                            else -> {
                                currentClick()
                                val released = withTimeoutOrNull(REPEAT_DELAY_MS - HOLD_CONFIRM_MS) { waitForUpOrCancellation(); true }
                                if (released == null) {
                                    while (true) {
                                        val ended = withTimeoutOrNull(REPEAT_INTERVAL_MS) { waitForUpOrCancellation(); true }
                                        if (ended != null) break
                                        currentClick()
                                    }
                                }
                            }
                        }
                    }
                    pressed = false
                }
            }
            .padding(horizontal = 10.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, color = fg, fontFamily = Sumi.Mono, fontSize = 12.sp, fontWeight = FontWeight.Medium)
    }
}

private const val HOLD_CONFIRM_MS = 120L
private const val REPEAT_DELAY_MS = 350L
private const val REPEAT_INTERVAL_MS = 40L
