package dev.sumi.terminal

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class SumiApp : Application()
