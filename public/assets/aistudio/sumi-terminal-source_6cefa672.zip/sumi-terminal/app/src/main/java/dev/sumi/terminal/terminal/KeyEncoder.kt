package dev.sumi.terminal.terminal

enum class TermKey { ESC, TAB, ENTER, BACKSPACE, HOME, END, PGUP, PGDN, INS, DEL, UP, DOWN, LEFT, RIGHT }

data class Mods(val ctrl: Boolean = false, val alt: Boolean = false, val shift: Boolean = false) {
    val any get() = ctrl || alt || shift
    /** Parâmetro xterm: 1 + (shift=1, alt=2, ctrl=4). */
    val xterm get() = 1 + (if (shift) 1 else 0) + (if (alt) 2 else 0) + (if (ctrl) 4 else 0)
}

/** Converte teclas e texto + modificadores nas sequências enviadas ao PTY (Ctrl+C -> 0x03, Tab -> 0x09...). */
object KeyEncoder {
    private const val ESC = "\u001B"

    fun encode(key: TermKey, m: Mods, appCursor: Boolean): ByteArray = when (key) {
        TermKey.ESC -> bytes(ESC)
        TermKey.TAB -> bytes(if (m.shift) "$ESC[Z" else "\t")
        TermKey.ENTER -> bytes(if (m.alt) "$ESC\r" else "\r")
        TermKey.BACKSPACE -> bytes(if (m.alt) "$ESC\u007F" else if (m.ctrl) "\b" else "\u007F")
        TermKey.UP -> cursor('A', m, appCursor)
        TermKey.DOWN -> cursor('B', m, appCursor)
        TermKey.RIGHT -> cursor('C', m, appCursor)
        TermKey.LEFT -> cursor('D', m, appCursor)
        TermKey.HOME -> cursor('H', m, appCursor)
        TermKey.END -> cursor('F', m, appCursor)
        TermKey.INS -> tilde(2, m)
        TermKey.DEL -> tilde(3, m)
        TermKey.PGUP -> tilde(5, m)
        TermKey.PGDN -> tilde(6, m)
    }

    fun encodeText(text: String, m: Mods): ByteArray {
        if (!m.any) return text.toByteArray(Charsets.UTF_8)
        val out = StringBuilder()
        for (c in text) {
            var ch = c
            if (m.shift) ch = ch.uppercaseChar()
            if (m.ctrl) {
                val code = when (ch) {
                    in 'a'..'z' -> ch - 'a' + 1
                    in 'A'..'Z' -> ch - 'A' + 1
                    in '@'..'_' -> ch - '@'
                    ' ' -> 0
                    '?' -> 127
                    else -> -1
                }
                if (code >= 0) ch = code.toChar()
            }
            if (m.alt) out.append(ESC)
            out.append(ch)
        }
        return out.toString().toByteArray()
    }

    private fun cursor(final: Char, m: Mods, app: Boolean) = bytes(
        when {
            m.xterm > 1 -> "$ESC[1;${m.xterm}$final"
            app -> "${ESC}O$final"
            else -> "$ESC[$final"
        }
    )

    private fun tilde(n: Int, m: Mods) = bytes(if (m.xterm > 1) "$ESC[$n;${m.xterm}~" else "$ESC[$n~")
    private fun bytes(s: String) = s.toByteArray()
}
