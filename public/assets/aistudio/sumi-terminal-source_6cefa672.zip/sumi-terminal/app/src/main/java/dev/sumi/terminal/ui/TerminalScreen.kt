package dev.sumi.terminal.ui

import android.graphics.Paint
import android.graphics.Typeface
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.foundation.clickable
import androidx.compose.ui.Alignment
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import android.graphics.BitmapFactory
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.IntSize
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.layout.onSizeChanged
import dev.sumi.terminal.terminal.TermKey
import dev.sumi.terminal.terminal.TerminalBuffer

@Composable
fun TerminalScreen(vm: TerminalViewModel = hiltViewModel(), onKeepScreenOn: (Boolean) -> Unit, onOpenFiles: () -> Unit) {
    val state by vm.state.collectAsState()
    val tabs by vm.tabs.collectAsState()
    val activeId by vm.activeId.collectAsState()
    val clipboard = LocalClipboardManager.current
    val keyboard = LocalSoftwareKeyboardController.current
    val focus = remember { FocusRequester() }
    var appearanceOpen by remember { mutableStateOf(false) }

    LaunchedEffect(state.sessionId) { focus.requestFocus(); keyboard?.show() }
    LaunchedEffect(state.keepScreenOn) { onKeepScreenOn(state.keepScreenOn) }
    LaunchedEffect(Unit) {
        vm.effects.collect { e ->
            when (e) {
                is TerminalEffect.CopyToClipboard -> clipboard.setText(AnnotatedString(e.text))
                TerminalEffect.ReadClipboard -> clipboard.getText()?.text?.let { vm.dispatch(TerminalIntent.Paste(it)) }
            }
        }
    }

    // Os insets (status bar + imePadding) são aplicados na raiz (MainActivity): a coluna encolhe
    // quando o IME aparece e a AccessoryBar (último filho) encosta na borda superior do teclado.
    Column(Modifier.fillMaxSize().background(Sumi.Sumi1)) {
        TabBar(
            sessions = tabs, activeId = activeId,
            onSelect = { vm.dispatch(TerminalIntent.SelectTab(it)) },
            onClose = { vm.dispatch(TerminalIntent.CloseTab(it)) },
            onNew = { vm.dispatch(TerminalIntent.NewTab) },
            onOpenFiles = onOpenFiles,
            onAppearance = { appearanceOpen = true },
        )
        Box(Modifier.weight(1f).fillMaxWidth()) {
            TerminalCanvas(vm, state, onTap = { focus.requestFocus(); keyboard?.show() })
            ImeCaptureField(vm::dispatch, focus, resetKey = state.inputReset, pendingPaste = state.pendingPaste)
        }
        AccessoryBar(state, vm::dispatch)
        if (appearanceOpen) AppearancePanel { appearanceOpen = false }
    }
}

@Composable
private fun AppearancePanel(onClose: () -> Unit) {
    val context = LocalContext.current
    val pickBackground = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri ?: return@rememberLauncherForActivityResult
        runCatching { context.contentResolver.openInputStream(uri)?.use(BitmapFactory::decodeStream)?.asImageBitmap() }
            .getOrNull()?.let { TerminalAppearance.backgroundImage = it }
    }
    Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.58f)).clickable { onClose() }) {
        Column(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                .background(Sumi.Sumi2, RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp))
                .padding(20.dp), verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(14.dp),
        ) {
            Text("aparência do terminal", color = Sumi.Paper, fontFamily = Sumi.Mono, fontSize = 16.sp)
            Text("paleta", color = Sumi.Muted, fontFamily = Sumi.Mono, fontSize = 11.sp)
            Row(horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp)) {
                PaletteChip("carvão", Color(0xFF121212), Color(0xFFE6E6E6), Color(0xFFE6C98A))
                PaletteChip("oceano", Color(0xFF071A24), Color(0xFFBCEBFF), Color(0xFF46C8FF))
                PaletteChip("âmbar", Color(0xFF1E160B), Color(0xFFFFE8B0), Color(0xFFFF9F43))
            }
            Text("cores automáticas: ${if (TerminalAppearance.autoCommandColors) "ligado" else "desligado"}", color = TerminalAppearance.accent, fontFamily = Sumi.Mono, fontSize = 12.sp, modifier = Modifier.clickable { TerminalAppearance.autoCommandColors = !TerminalAppearance.autoCommandColors }.padding(vertical = 6.dp))
            Text("carregar foto de fundo", color = TerminalAppearance.accent, fontFamily = Sumi.Mono, fontSize = 12.sp, modifier = Modifier.clickable { pickBackground.launch("image/*") }.padding(vertical = 6.dp))
            Text("brilho do fundo", color = Sumi.Muted, fontFamily = Sumi.Mono, fontSize = 11.sp)
            Slider(value = TerminalAppearance.brightness, onValueChange = { TerminalAppearance.brightness = it }, valueRange = 0.55f..1.35f)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = androidx.compose.foundation.layout.Arrangement.End) {
                Text("fechar", color = TerminalAppearance.accent, fontFamily = Sumi.Mono, fontSize = 13.sp, modifier = Modifier.clickable { onClose() }.padding(10.dp))
            }
        }
    }
}

@Composable
private fun PaletteChip(label: String, bg: Color, fg: Color, accent: Color) {
    Box(
        Modifier.width(96.dp).background(bg, RoundedCornerShape(9.dp)).clickable { TerminalAppearance.setPalette(bg, fg, accent) }.padding(12.dp),
    ) { Text(label, color = fg, fontFamily = Sumi.Mono, fontSize = 11.sp) }
}

/**
 * Campo invisível que mantém o IME nativo completo (sugestões, clipboard do Gboard, voz).
 * Calculamos o diff entre o texto anterior e o novo - inclusive durante composição - e enviamos
 * apenas (apagados, inseridos), então autocorreção e predição refletem em tempo real no PTY.
 */
@Composable
private fun ImeCaptureField(
    onIntent: (TerminalIntent) -> Unit,
    focus: FocusRequester,
    resetKey: Long,
    pendingPaste: String?,
) {
    var value by remember { mutableStateOf(TextFieldValue("")) }
    LaunchedEffect(resetKey) { value = TextFieldValue("", TextRange.Zero) }
    LaunchedEffect(pendingPaste) {
        pendingPaste?.let { pasted ->
            val start = value.selection.min
            val end = value.selection.max
            onIntent(TerminalIntent.TextDelta(end - start, pasted))
            val next = value.text.replaceRange(start, end, pasted)
            value = TextFieldValue(next, TextRange(start + pasted.length))
            onIntent(TerminalIntent.ConsumePaste)
        }
    }
    BasicTextField(
        value = value,
        onValueChange = { new ->
            val old = value.text
            // Comum-prefixo apenas fazia uma colagem no cursor reenviar também o sufixo
            // que já existia no campo invisível. Isso duplicava blocos e criava comandos mutantes.
            var prefix = 0
            while (prefix < old.length && prefix < new.text.length && old[prefix] == new.text[prefix]) prefix++
            var suffix = 0
            while (
                suffix < old.length - prefix && suffix < new.text.length - prefix &&
                old[old.length - 1 - suffix] == new.text[new.text.length - 1 - suffix]
            ) suffix++
            val deleted = old.length - prefix - suffix
            val insertedEnd = new.text.length - suffix
            val inserted = new.text.substring(prefix, insertedEnd)
            if (deleted > 0 || inserted.isNotEmpty()) onIntent(TerminalIntent.TextDelta(deleted, inserted))
            // Mantém pouco contexto para o teclado prever; zera quando não há composição ativa.
            value = if (new.composition == null && new.text.length > 48) TextFieldValue("", TextRange.Zero) else new
        },
        modifier = Modifier
            .height(1.dp).fillMaxWidth().alpha(0f)
            .focusRequester(focus)
            .onPreviewKeyEvent { ev ->
                // A seta já foi traduzida para o PTY no KeyDown; consuma também o KeyUp
                // para o IME não gerar um segundo [A/[B como texto.
                if (ev.type == KeyEventType.KeyUp && ev.key in setOf(Key.DirectionUp, Key.DirectionDown, Key.DirectionLeft, Key.DirectionRight)) return@onPreviewKeyEvent true
                if (ev.type != KeyEventType.KeyDown) return@onPreviewKeyEvent false
                val k = when (ev.key) {
                    Key.Enter, Key.NumPadEnter -> TermKey.ENTER
                    Key.Backspace -> if (value.text.isEmpty()) TermKey.BACKSPACE else null
                    Key.DirectionUp -> TermKey.UP; Key.DirectionDown -> TermKey.DOWN
                    Key.DirectionLeft -> TermKey.LEFT; Key.DirectionRight -> TermKey.RIGHT
                    Key.Escape -> TermKey.ESC; Key.Tab -> TermKey.TAB
                    Key.MoveHome -> TermKey.HOME; Key.MoveEnd -> TermKey.END
                    Key.PageUp -> TermKey.PGUP; Key.PageDown -> TermKey.PGDN
                    Key.Delete -> TermKey.DEL; Key.Insert -> TermKey.INS
                    else -> null
                }
                k?.let { onIntent(TerminalIntent.Key(it)); true } ?: false
            },
        keyboardOptions = KeyboardOptions(
            // Sugestões continuam disponíveis, mas o IME não pode substituir texto
            // nem adicionar maiúscula no início de frases.
            autoCorrectEnabled = false,
            capitalization = KeyboardCapitalization.None,
            keyboardType = KeyboardType.Text,
            imeAction = ImeAction.Send,
        ),
        keyboardActions = KeyboardActions(onSend = { onIntent(TerminalIntent.Key(TermKey.ENTER)) }),
    )
}

